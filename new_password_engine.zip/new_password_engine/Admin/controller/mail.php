<?php
require('../../phpmailer/PHPMailerAutoload.php');

$sql_mail = "SELECT * FROM mails WHERE status = 1";
 $result_mail = $conn->query($sql_mail);
 $row_mail = mysqli_fetch_assoc($result_mail);
 $mailHost = $row_mail['host'];
 $mailPort = $row_mail['port'];
 $mailUser = $row_mail['user_name'];
 $mailPassword = $row_mail['password'];
 $mailSender = $row_mail['sender'];
	  

if($_REQUEST['key']=='ServerGrant'){
	
	$htmlbody_owner = '
			 <html> 
				<body> 
					<h3 style=" text-transform:capitalize;">Hello '.$name_user_owner.'</h3> 
					<p>'.$requesterEmail.' is requested to '.$userName.' user on '.$serverName.' server</p>
					<p> Please approve </p>
					<a href="http://localhost:8080/password-engine/index.php">www.password-engine-vodafone.com</a>
				</body> 
			 </html>';
			 
	$subject_owner = "Requested for user access";
	
	sendMail($mailHost, $mailPort, $mailUser, $mailPassword, $mailSender, $email_user_owner, $subject_owner, $htmlbody_owner);
	
	
	
	$htmlbody_requester = '
			 <html> 
				<body> 
					<h3 style=" text-transform:capitalize;">Hello '.$requesterName.'</h3> 
					<p>You have successfully requested to '.$userName.' user on '.$serverName.' server</p>
				</body> 
			 </html>';
			 
	$subject_requester = "Request for user access";
	
	sendMail($mailHost, $mailPort, $mailUser, $mailPassword, $mailSender, $requesterEmail, $subject_requester, $htmlbody_requester);
}	



	
if($_REQUEST['key']=='insertUser'){
	
	$htmlbody = '
			 <html> 
				<body> 
					<h3 style=" text-transform:capitalize;">Hello '.$f_name.' '.$f_name.'</h3> 
					<p>Welcome to Vodafone!</p>
					<p>Your are successfully registerd on our password portal</p>
					<p>Please find your login credential below</p>
					<table style="text-align:left"> 
					  <tr> 
						<th>User:</th>
						<td>'.$email.'</td> 
					  </tr> 
					  <tr> 
						<th>Password:</th>
						<td>'.$password.'</td> 
					  </tr> 
					  <tr> 
						<th>Portal url:</th>
						<td>
						  <a href="http://localhost:81/password/index.php">www.password-engine-vodafone.com</a>
						</td> 
					  </tr> 
					</table> 
				</body> 
			 </html>';
			 
	$subject = "Your are successfully registerd on password portal";
	
	sendMail($mailHost, $mailPort, $mailUser, $mailPassword, $mailSender, $email, $subject, $htmlbody);
}





if($_REQUEST['key']=='UserServer'){
	$htmlbody = '
			 <html> 
				<body> 
					<h3 style=" text-transform:capitalize;">Hello '.$uName.'</h3> 
					<p>Welcome to Vodafone!</p>
					<p>Your are successfully created user on our password portal</p>
					<p>Please find your login credential below</p>
					<table style="text-align:left"> 
					  <tr> 
						<th>User Name:</th>
						<td>'.$userName.'</td> 
					  </tr> 
					  <tr> 
						<th>Password:</th>
						<td>'.$password.'</td> 
					  </tr>
                      <tr> 
						<th>Key:</th>
						<td>'.$secure_key.'</td> 
					  </tr>					  
					  <tr> 
						<th>Portal url:</th>
						<td>
						  <a href="http://localhost:81/password/index.php">www.password-engine-vodafone.com</a>
						</td> 
					  </tr> 
					</table> 
				</body> 
			 </html>';
			 
	$subject = "Your are successfully created user on password portal";
	
	sendMail($mailHost, $mailPort, $mailUser, $mailPassword, $mailSender, $uEmail, $subject, $htmlbody);
}





function sendMail($host, $port, $userName, $password, $sender, $email, $subject, $htmlbody){
	
	$mail = new PHPMailer;
	$mail->isSMTP();
	$mail->SMTPDebug = 0;
	$mail->Host = $host;
	$mail->Port = (int)$port;
	
	if(isset($userName) && isset($password)){
	
		$mail->SMTPSecure = 'tls';
	    $mail->SMTPAuth = true;
	    $mail->Username = $userName;
	    $mail->Password = $password;
	}
	
	$mail->setFrom($sender);
	$mail->addAddress($email);
    $mail->Subject = $subject;
	$mail->msgHTML($htmlbody);
	$mail->send();
	
	if (!$mail->send()) {
		echo "Mailer Error: ".$mail->ErrorInfo;
	}
}

?>