<?php

include('../../dbConnection.php');

$msg = "";


if($_REQUEST['key']=='editAdmin'){
	
	if(($_REQUEST['f_name'] == '') || ($_REQUEST['l_name'] == '') || ($_REQUEST['email'] == '') || ($_REQUEST['mobile'] == '') || !isset($_REQUEST['status']) || !isset($_REQUEST['market'])){
		
		$msg = 1; //"Please fill all the fields";
		
		$myObj = new stdClass();
		$myObj->f_name = $_REQUEST['f_name']=='' ? "First name is required" : "";
		$myObj->l_name = $_REQUEST['l_name']=='' ? "Last name is required" : "";
		$myObj->email =  $_REQUEST['email']==''  ? "Email is required" : "";
		$myObj->mobile = $_REQUEST['mobile']=='' ? "Mobile is required" : "";
		$myObj->market = !isset($_REQUEST['market']) ? "Market is required" : "";
		$myObj->status = !isset($_REQUEST['status']) ? "Status is required" : "";
		$myObj->code = 202;
		$myJSON = json_encode($myObj);
		echo $myJSON;
		die();
	}
	else{
		$id = (int)$_REQUEST['id'];
		$f_name = $_REQUEST['f_name'];
		$l_name = $_REQUEST['l_name'];
		$email = $_REQUEST['email'];
		$mobile = $_REQUEST['mobile'];
		$password = rand (100,999);
		$status = $_REQUEST['status'];
		$market = $_REQUEST['market'];
		
		
		$myObj = new stdClass();
		
		$sql_check_email = "SELECT email FROM admins WHERE email = '$email' AND id != $id";
		 $result_check_email = $conn->query($sql_check_email);
		 $myObj->email = mysqli_num_rows($result_check_email)>=1 ? "This Email is already exist" : "";
		 
		$sql_check_mobile = "SELECT mobile FROM admins WHERE mobile = '$mobile' AND id != $id";
		 $result_check_mobile = $conn->query($sql_check_mobile);
		 $myObj->mobile = mysqli_num_rows($result_check_mobile)>=1 ? "This Mobile is already exist" : "";
		 
		 if($myObj->mobile != '' || $myObj->email != ''){
			$myObj->code = 202;
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		 }
		
		
		$sql = "UPDATE admins SET f_name='$f_name', l_name='$l_name', email='$email', mobile='$mobile', password='$password', status='$status', market_id='$market' WHERE id = $id ";
		
		if($conn->query($sql) === TRUE) {
		   $msg = 2; //"Inserted Successfully";
		} else {
		   $msg = 3; //"Somthing Went Wrong";
		   
		   //echo "Error: " . $sql . "<br>" . $conn->error;
		}

		$conn->close();
	
	}
} 



if($_REQUEST['key']=='editRole'){
	
	if(($_REQUEST['role'] == '') || !isset($_REQUEST['status'])){
		
		$myObj = new stdClass();
		$myObj->role = $_REQUEST['role']=='' ? "Role is required" : "";
		//$myObj->market = !isset($_REQUEST['market']) ? "Market is required" : "";
		$myObj->status = !isset($_REQUEST['status']) ? "Status is required" : "";
		$myObj->code = 202;
		$myJSON = json_encode($myObj);
		echo $myJSON;
		die();
	}
	else{
		$id = (int)$_REQUEST['id'];
		$role = $_REQUEST['role'];
		$market = 1;
		$status = $_REQUEST['status'];
		
		$myObj = new stdClass();
		
		$sql_check_role = "SELECT role FROM roles WHERE role = '$role' AND id != $id";
		 $result_check_role = $conn->query($sql_check_role);
		 $myObj->role = mysqli_num_rows($result_check_role)>=1 ? "This Role is already exist" : "";
		 
		if($myObj->role != ''){
			$myObj->code = 202;
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		 }
		
		$sql = "UPDATE roles SET role='$role',status = $status, market_id = '$market' WHERE id = $id ";
		
		if($conn->query($sql) === TRUE) {
			$myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Updated Successfully";
			$myObj->msg = "success";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
			
		} else {
		    $myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Somthing Went Wrong";
			$myObj->msg = "info";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		    //echo "Error: " . $sql . "<br>" . $conn->error;
		}
	  $conn->close();
	}
} 


if($_REQUEST['key']=='editMarket'){
	
	if(($_REQUEST['market'] == '') || !isset($_REQUEST['status'])){
		
		$msg = 1; //"Please fill all the fields";
		
		$myObj = new stdClass();
		$myObj->market = $_REQUEST['market']=='' ? "Market is required" : "";
		$myObj->status = !isset($_REQUEST['status']) ? "Status is required" : "";
		$myObj->code = 202;
		$myJSON = json_encode($myObj);
		echo $myJSON;
		die();
	}
	else{
		$id = (int)$_REQUEST['id'];
		//echo $id; echo gettype($id); die();
		$market = $_REQUEST['market'];
		$status = $_REQUEST['status'];
		
		$myObj = new stdClass();
		
		$sql_check_market = "SELECT market FROM markets WHERE market = '$market' AND id != $id";
		 $result_check_market = $conn->query($sql_check_market);
		 $myObj->market = mysqli_num_rows($result_check_market)>=1 ? "This Market is already exist" : "";
		 
		if($myObj->market != ''){
			$myObj->code = 202;
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		 }
		
		$sql = "UPDATE markets SET market='$market', status='$status' WHERE id = $id ";
		
		if($conn->query($sql) === TRUE) {
		   $msg = 2; //"Inserted Successfully";
		} else {
		   $msg = 3; //"Somthing Went Wrong";
		   
		   //echo "Error: " . $sql . "<br>" . $conn->error;
		}

		$conn->close();
	
	}
} 



if($_REQUEST['key']=='editOwner'){
	
	if(($_REQUEST['ticket'] == '') || ($_REQUEST['userName'] == '')|| ($_REQUEST['host'] == '')|| ($_REQUEST['email'] == '') || !isset($_REQUEST['status'])){
		
		$myObj = new stdClass();
		$myObj->ticket = $_REQUEST['ticket']=='' ? "Ticket No. is required" : "";
		$myObj->userName = $_REQUEST['userName']=='' ? "User name is required" : "";
		$myObj->email = $_REQUEST['email']=='' ? "Email is required" : "";
		$myObj->host = $_REQUEST['host']=='' ? "Host name is required" : "";
		//$myObj->market = !isset($_REQUEST['market']) ? "Market is required" : "";
		$myObj->status = !isset($_REQUEST['status']) ? "Status is required" : "";
		$myObj->code = 202;
		$myJSON = json_encode($myObj);
		echo $myJSON;
		die();
	}
	else{
		$id = (int)$_REQUEST['id'];
		$userName = $_REQUEST['userName'];
		$email = $_REQUEST['email'];
		$market = 1;
		$status = $_REQUEST['status'];
		
		$myObj = new stdClass();
		
		$sql_check_userName = "SELECT user FROM server_users WHERE user = '$userName' AND id != $id";
		 $result_check_userName = $conn->query($sql_check_userName);
		 $myObj->userName = mysqli_num_rows($result_check_userName)>=1 ? "This User name is already exist" : "";
		 
		 if($myObj->userName != ''){
			$myObj->code = 202;
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		 }
		
		$sql = "UPDATE server_users SET user='$userName', status='$status' WHERE id = $id ";
		
		if($conn->query($sql) === TRUE) {
			$myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Updated Successfully";
			$myObj->msg = "success";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
			
		} else {
		    $myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Somthing Went Wrong";
			$myObj->msg = "info";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		    //echo "Error: " . $sql . "<br>" . $conn->error;
		}
	  $conn->close();
	}
} 


if($_REQUEST['key']=='editServer'){
	
	if(($_REQUEST['ticket'] == '') || ($_REQUEST['host'] == '') || ($_REQUEST['ip'] == '') || ($_REQUEST['password'] == '') || !isset($_REQUEST['os_type'])|| !isset($_REQUEST['status'])){
		 
		$msg = 1; //"Please fill all the fields";
		
		$myObj = new stdClass();
		$myObj->ticket = $_REQUEST['ticket']=='' ? "Ticket No. is required" : "";
		$myObj->host = $_REQUEST['host']=='' ? "Host is required" : "";
		$myObj->ip = $_REQUEST['ip']=='' ? "Ip is required" : "";
		//$myObj->port = $_REQUEST['port']=='' ? "Port is required" : "";
		$myObj->password = $_REQUEST['password']=='' ? "Password is required" : "";
		$myObj->os_type = !isset($_REQUEST['os_type']) ? "Os Type is required" : "";
		//$myObj->market = !isset($_REQUEST['market']) ? "Market is required" : "";
		$myObj->status = !isset($_REQUEST['status']) ? "Status is required" : "";
		$myObj->code = 202;
		$myJSON = json_encode($myObj);
		echo $myJSON;
		die();
	}
	else{
		$id = (int)$_REQUEST['id'];
		$ticket = $_REQUEST['ticket'];
		$host_name = $_REQUEST['host'];
		$ip_address = $_REQUEST['ip'];
		//$port = $_REQUEST['port'];
		$os_type = $_REQUEST['os_type'];
		$password = $_REQUEST['password'];
		$market = 1;
		$status = $_REQUEST['status'];
		
		$myObj = new stdClass();
		
		$sql_check_host = "SELECT host_name FROM servers WHERE host_name = '$host_name' AND id != $id";
		 $result_check_host = $conn->query($sql_check_host);
		 $myObj->host = mysqli_num_rows($result_check_host)>=1 ? "This Host is already exist" : "";
		 
		 if($myObj->host != ''){
			$myObj->code = 202;
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		 }
		
		$sql = "UPDATE servers SET host_name='$host_name', ip_address='$ip_address', os_type='$os_type', password='$password', market_id='$market', status='$status' WHERE id = $id ";
		
		
		if($conn->query($sql) === TRUE) {
			$myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Updated Successfully";
			$myObj->msg = "success";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
			
		} else {
		    $myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Somthing Went Wrong";
			$myObj->msg = "info";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		    //echo "Error: " . $sql . "<br>" . $conn->error;
		}
	  $conn->close();
	}
} 



if($_REQUEST['key']=='editUser'){
	
	if(($_REQUEST['ticket'] == '') || ($_REQUEST['unix_id'] == '') || ($_REQUEST['f_name'] == '') || ($_REQUEST['l_name'] == '') || ($_REQUEST['email'] == '') || !isset($_REQUEST['status'])){
		
		$myObj = new stdClass();
		$myObj->ticket = $_REQUEST['ticket']=='' ? "Ticket No. is required" : "";
		$myObj->unix_id = $_REQUEST['unix_id']=='' ? "Unix Id is required" : "";
		$myObj->f_name = $_REQUEST['f_name']=='' ? "First Name is required" : "";
		$myObj->l_name = $_REQUEST['l_name']=='' ? "Last Name is required" : "";
		$myObj->email = $_REQUEST['email']=='' ? "Email is required" : "";
		//$myObj->mobile = $_REQUEST['mobile']=='' ? "Mobile is required" : "";
		//$myObj->market = !isset($_REQUEST['market']) ? "Market is required" : "";
		//$myObj->gender = !isset($_REQUEST['gender']) ? "Gemder is required" : "";
		$myObj->status = !isset($_REQUEST['status']) ? "Status is required" : "";
		$myObj->code = 202;
		$myJSON = json_encode($myObj);
		echo $myJSON;
		die();
	}
	else{
		$id = (int)$_REQUEST['id'];
		$ticket = $_REQUEST['ticket'];
		$unix_id = $_REQUEST['unix_id'];
		$f_name = $_REQUEST['f_name'];
		$l_name = $_REQUEST['l_name'];
		$email = $_REQUEST['email'];
		//$mobile = $_REQUEST['mobile'];
		$market_id = 1;
		//$gender = $_REQUEST['gender'];
		$status = $_REQUEST['status'];
		$password = rand (100,999);
		
		
		$myObj = new stdClass();
		
		$sql_check_email = "SELECT email FROM users WHERE email = '$email' AND id != $id";
		 $result_check_email = $conn->query($sql_check_email);
		 $myObj->email = mysqli_num_rows($result_check_email)>=1 ? "This Email is already exist" : "";
		 
		/* $sql_check_mobile = "SELECT mobile FROM users WHERE mobile = '$mobile' AND id != $id";
		 $result_check_mobile = $conn->query($sql_check_mobile);
		 $myObj->mobile = mysqli_num_rows($result_check_mobile)>=1 ? "This Mobile is already exist" : ""; */
		 
		 if($myObj->email != ''){
			$myObj->code = 202;
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		 }
		
		$sql = "UPDATE users SET unix_id='$unix_id', market_id='$market_id', f_name='$f_name', l_name='$l_name', email='$email', password='$password', status='$status' WHERE id = $id ";
		
		if($conn->query($sql) === TRUE) {
			$myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Updated Successfully";
			$myObj->msg = "success";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
			
		} else {
		    $myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Somthing Went Wrong";
			$myObj->msg = "info";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		    //echo "Error: " . $sql . "<br>" . $conn->error;
		}
	  $conn->close();
	}
} 






if($_REQUEST['key']=='updateRequestRole'){
	
	if(($_REQUEST['id'] == '') || ($_REQUEST['value'] == '') ){
		
		$myObj = new stdClass();
		$myObj->code = 200;
		$myObj->text = "Somthing Went Wrong";
		$myObj->msg = "info";
		$myJSON = json_encode($myObj);
		echo $myJSON;
		die();
	}
	else{
		$id = (int)$_REQUEST['id'];
		$value = $_REQUEST['value'];
		$description = $_REQUEST['description'] ?? null;
		
		if($value == 'Pending'){
			$p=1;$a=0;$d=0;
		}
		if($value == 'Approved'){
			$p=0;$a=1;$d=0;
		}
		if($value == 'Declined'){
			$p=0;$a=0;$d=1;
		}
		
		$sql = "UPDATE role_requests SET is_approved='$a', is_pending='$p', is_declined='$d', description='$description' WHERE id = $id ";
		
		if($conn->query($sql) === TRUE) {
			$myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = $value." Successfully";
			$myObj->msg = "success";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
			
		} else {
		    $myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Somthing Went Wrong";
			$myObj->msg = "info";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		    //echo "Error: " . $sql . "<br>" . $conn->error;
		}
	  $conn->close();
	}
} 





/*
if(isset($_REQUEST['update_user'])){
	if(($_REQUEST['f_name'] == '') || ($_REQUEST['l_name'] == '') || ($_REQUEST['email'] == '') || ($_REQUEST['phone'] == '') || ($_REQUEST['mobile'] == '') || ($_REQUEST['company'] == '') || ($_REQUEST['department'] == '') || ($_REQUEST['position'] == '')){
		$alert = '<div class="alert alert-warning col-sm-12" role="alert"> Please fill all the fields </div>';
	}
	else{
		$f_name = $_REQUEST['f_name'];
		$l_name = $_REQUEST['l_name'];
		$email = $_REQUEST['email'];
		$phone = $_REQUEST['phone'];
		$mobile = $_REQUEST['mobile'];
		$company = $_REQUEST['company'];
		$department = $_REQUEST['department'];
		$position = $_REQUEST['position'];
		$date = $_REQUEST['date'];
		$status = 1;
		
		$sql = 'UPDATE PWUSERS SET FIRST_NAME=:f_name, LAST_NAME=:l_name, EMAIL=:email, PHONE=:phone, MOBILE=:mobile, COMPANY=:company, DEPARTMENT=:department, POSITION=:position, STATUS=:status WHERE ID=:id';
		
		$parse = oci_parse($connection, $sql);
		
		
		oci_bind_by_name($parse, ':id', $id);
		oci_bind_by_name($parse, ':f_name', $f_name);
		oci_bind_by_name($parse, ':l_name', $l_name);
		oci_bind_by_name($parse, ':email', $email);
		oci_bind_by_name($parse, ':phone', $phone);
		oci_bind_by_name($parse, ':mobile', $mobile);
		oci_bind_by_name($parse, ':company', $company);
		oci_bind_by_name($parse, ':department', $department);
		oci_bind_by_name($parse, ':position', $position);
		//oci_bind_by_name($parse, ':date', $date);
		oci_bind_by_name($parse, ':status', $status);
		
		$execute = oci_execute($parse);
		
		
		if($execute){
			$alert = '<div class="alert alert-success col-sm-12" role="alert"> Inserted successfully </div>';
		}
		else{
			$alert = '<div class="alert alert-danger col-sm-12" role="alert"> Somthing went wrong </div>';
		}
		
		oci_free_statement($parse);
		oci_close($connection);
	}
}

if(isset($_REQUEST['update_role'])){
	if(($_REQUEST['name'] == '') || ($_REQUEST['description'] == '') || ($_REQUEST['status'] == '')){
		$alert = '<div class="alert alert-warning col-sm-12" role="alert"> Please fill all the fields </div>';
	}
	else{
		$name = $_REQUEST['name'];
		$description = $_REQUEST['description'];
		$status = $_REQUEST['status'];
		
		$sql = 'UPDATE PWROLES SET NAME=:name, DESCRIPTION=:description, STATUS=:status WHERE ID=:id';
		
		$parse = oci_parse($connection, $sql);
		
		
		oci_bind_by_name($parse, ':id', $id);
		oci_bind_by_name($parse, ':name', $name);
		oci_bind_by_name($parse, ':description', $description);
		oci_bind_by_name($parse, ':status', $status);
		
		$execute = oci_execute($parse);
		
		
		if($execute){
			$alert = '<div class="alert alert-success col-sm-12" role="alert"> Inserted successfully </div>';
		}
		else{
			$alert = '<div class="alert alert-danger col-sm-12" role="alert"> Somthing went wrong </div>';
		}
		
		oci_free_statement($parse);
		oci_close($connection);
	}
}


if(isset($_REQUEST['update_groups'])){
	if(($_REQUEST['name'] == '') || ($_REQUEST['description'] == '') || ($_REQUEST['status'] == '')){
		$alert = '<div class="alert alert-warning col-sm-12" role="alert"> Please fill all the fields </div>';
	}
	else{
		$name = $_REQUEST['name'];
		$description = $_REQUEST['description'];
		$status = $_REQUEST['status'];
		
		$sql = 'UPDATE PWGROUPS SET NAME=:name, DESCRIPTION=:description, STATUS=:status WHERE ID=:id';
		
		$parse = oci_parse($connection, $sql);
		
		
		oci_bind_by_name($parse, ':id', $id);
		oci_bind_by_name($parse, ':name', $name);
		oci_bind_by_name($parse, ':description', $description);
		oci_bind_by_name($parse, ':status', $status);
		
		$execute = oci_execute($parse);
		
		
		if($execute){
			$alert = '<div class="alert alert-success col-sm-12" role="alert"> Inserted successfully </div>';
		}
		else{
			$alert = '<div class="alert alert-danger col-sm-12" role="alert"> Somthing went wrong </div>';
		}
		
		oci_free_statement($parse);
		oci_close($connection);
	}
}


if(isset($_REQUEST['update_connection'])){
	if(($_REQUEST['f_name'] == '') || ($_REQUEST['l_name'] == '') || ($_REQUEST['email'] == '') || ($_REQUEST['phone'] == '') || ($_REQUEST['mobile'] == '') || ($_REQUEST['company'] == '') || ($_REQUEST['department'] == '') || ($_REQUEST['position'] == '')){
		$alert = '<div class="alert alert-warning col-sm-12" role="alert"> Please fill all the fields </div>';
	}
	else{
		$f_name = $_REQUEST['f_name'];
		$l_name = $_REQUEST['l_name'];
		$email = $_REQUEST['email'];
		$phone = $_REQUEST['phone'];
		$mobile = $_REQUEST['mobile'];
		$company = $_REQUEST['company'];
		$department = $_REQUEST['department'];
		$position = $_REQUEST['position'];
		$date = $_REQUEST['date'];
		$status = 1;
		
		$sql = 'UPDATE PWUSERS SET FIRST_NAME=:f_name, LAST_NAME=:l_name, EMAIL=:email, PHONE=:phone, MOBILE=:mobile, COMPANY=:company, DEPARTMENT=:department, POSITION=:position, STATUS=:status WHERE ID=:user_id';
		
		$parse = oci_parse($connection, $sql);
		
		
		oci_bind_by_name($parse, ':user_id', $user_id);
		oci_bind_by_name($parse, ':f_name', $f_name);
		oci_bind_by_name($parse, ':l_name', $l_name);
		oci_bind_by_name($parse, ':email', $email);
		oci_bind_by_name($parse, ':phone', $phone);
		oci_bind_by_name($parse, ':mobile', $mobile);
		oci_bind_by_name($parse, ':company', $company);
		oci_bind_by_name($parse, ':department', $department);
		oci_bind_by_name($parse, ':position', $position);
		//oci_bind_by_name($parse, ':date', $date);
		oci_bind_by_name($parse, ':status', $status);
		
		$execute = oci_execute($parse);
		
		
		if($execute){
			$alert = '<div class="alert alert-success col-sm-12" role="alert"> Inserted successfully </div>';
		}
		else{
			$alert = '<div class="alert alert-danger col-sm-12" role="alert"> Somthing went wrong </div>';
		}
		
		oci_free_statement($parse);
		oci_close($connection);
	}
}

*/

?>




<?php
if($msg == 1){
$myObj = new stdClass();
$myObj->msg = '
	 <div id="successMsgModal" class="modal fade delete-modal" role="dialog">
		<div class="modal-dialog modal-dialog-centered">
			<div class="modal-content">
			   <div class="modal-body text-center">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<img src="assets/img/sent.png" alt="" width="50" height="46">
					<h3 class="delete_class">Please fill all the fields</h3>
					<div class="m-t-20"> 
						<a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
					</div>
				</div>
			</div>
		</div>
	</div>';
$myObj->code = 200;
$myJSON = json_encode($myObj);
echo $myJSON;
die();
} ?>


<?php
if($msg == 2){
$myObj = new stdClass();
$myObj->msg = '
	 <div id="successMsgModal" class="modal fade delete-modal" role="dialog">
		<div class="modal-dialog modal-dialog-centered">
			<div class="modal-content">
			   <div class="modal-body text-center">
					<button type="button" class="close" data-dismiss="modal" onclick="reload()">&times;</button>
					<img src="assets/img/sent.png" alt="" width="50" height="46">
					<h3 class="delete_class">Updated Successfully</h3>
					<div class="m-t-20"> 
						<a href="#" class="btn btn-white" data-dismiss="modal" onclick="reload()">Close</a>
					</div>
				</div>
			</div>
		</div>
	</div>';
$myObj->code = 200;
$myJSON = json_encode($myObj);
echo $myJSON;
die();
} ?>


<?php
if($msg == 3){
$myObj = new stdClass();
$myObj->msg = '
	 <div id="successMsgModal" class="modal fade delete-modal" role="dialog">
		<div class="modal-dialog modal-dialog-centered">
			<div class="modal-content">
			   <div class="modal-body text-center">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<img src="assets/img/sent.png" alt="" width="50" height="46">
					<h3 class="delete_class">Somthing Went Wrong</h3>
					<div class="m-t-20"> 
						<a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
					</div>
				</div>
			</div>
		</div>
	</div>';
$myObj->code = 200;
$myJSON = json_encode($myObj);
echo $myJSON;
die();
} ?>




<?php
if($msg == 4){
$myObj = new stdClass();
$myObj->msg = '
	 <div id="successMsgModal" class="modal fade delete-modal" role="dialog">
		<div class="modal-dialog modal-dialog-centered">
			<div class="modal-content">
			   <div class="modal-body text-center">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<img src="assets/img/sent.png" alt="" width="50" height="46">
					<h3 class="delete_class">Undefined error please try after some time</h3>
					<div class="m-t-20"> 
						<a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
					</div>
				</div>
			</div>
		</div>
	</div>';
$myObj->code = 200;
$myJSON = json_encode($myObj);
echo $myJSON;
die();
} ?>
