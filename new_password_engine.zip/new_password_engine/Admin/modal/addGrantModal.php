<?php

$modalName = "addGrantModal";

include('../controller/modal.php');

?>


<div class="modal fade delete-modal" id="addFormModal">
   <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">

		  <!-- Modal Header -->
		  <div class="modal-header">
			<h4 class="modal-title">Assign Role</h4>
			<button type="button" class="close" data-dismiss="modal">&times;</button>
		  </div>

		  <!-- Modal body -->
		  <div class="modal-body">
			<form id="addFormData">
				<div class="row formtype">
				    <div class="col-md-12">
					   <div class="form-group">
					      <label>Ticket No. <span class="text-danger">*</span></label>
						  <input class="form-control" type="text" id="ticket" name="ticket" placeholder="Ticket number" required />
						  <div id="ErrorTicket" class="form-control-error"></div>
					   </div>
					</div>
					
				    <div class="col-md-12">
						<div class="form-group">
							<label>Select Role</label>
							<select class="form-control" id="role" name="role">
								<option value="" disabled selected>Select Role</option>
								  <?php while($rRow = $rResult->fetch_assoc()){ ?>  
									<option value="<?php echo $rRow['id']; ?>"> <?php echo $rRow['role']; ?> </option>  
								  <?php }?>
							</select>
							<div id="ErrorRole" class="form-control-error"></div>
						</div>
					</div>
					
					<div class="col-md-6">
					  <div class="form-group">
						<label>Status</label>
						  <select class="form-control" id="status" name="status">
							  <option value="1">Active</option>
							  <option value="0">Inactive</option>
						  </select>
						  <div id="ErrorStatus" class="form-control-error"></div>
					  </div>
					</div>
					
					<div class="col-md-6">
					  <div class="form-group">
						<label>Action</label>
						  <select class="form-control" id="action" name="action">
							  <option value="add">Add</option>
							  <option value="delete">Delete</option>
						  </select>
						  <div id="ErrorAction" class="form-control-error"></div>
					  </div>
					</div>
				  </div>
				</div>
				<div class="modal-footer float-right">
				  <button type="submit" class="btn btn-danger" onclick="AssigneOrDelete('&uID=<?=$uID;?>&uMID=<?=$uMID;?>&key=Grant')">Save</button>
				  <button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
			   </div>
			</form>
		  </div>
		  <!-- Modal body end-->
      </div>
   </div>
</div>

