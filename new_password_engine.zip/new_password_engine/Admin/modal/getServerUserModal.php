<?php
include('../../dbConnection.php');

$server_id = trim($_POST['server']);

$sSql = "SELECT id, user FROM server_users WHERE server_id = '$server_id'";   
	$sResult = $conn->query($sSql);	
?>


  <label for="server">Select user</label>
  <select class="item inn form-control" name="server_user" id="server_user""> 
	  <option value="" disabled selected>Select user</option> 
		<?php 
		  while($sRow = mysqli_fetch_array($sResult)) { ?> 
			  <option value="<?php echo $sRow['id']; ?>"><?php echo $sRow['user']; ?></option>
	   <?php } ?>				 
  </select>
  <div id="ErrorUserName" class="form-control-error"></div>
 
 
<script> 
$(document).ready(function() {
	$('#server_user').select2({
		placeholder: "Select User",
		allowClear: true
	});
});
</script>