<!DOCTYPE html>
<!-- Created By CodingNepal - www.codingnepalweb.com -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Password Engine </title>
	<link rel="shortcut icon" type="image/x-icon" href="img/logo.png">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
	
	<style>
	@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap');
	*{
	  margin: 0;
	  padding: 0;
	  box-sizing: border-box;
	  font-family: 'Poppins',sans-serif;
	}
	::selection{
	  color: #000;
	  background: #fff;
	}
	nav{
	  position: fixed;
	  background: #1b1b1b;
	  width: 100%;
	  padding: 10px 0;
	  z-index: 12;
	}
	nav .menu{
	  max-width: 1250px;
	  margin: auto;
	  display: flex;
	  align-items: center;
	  justify-content: space-between;
	  padding: 0 20px;
	}
	.menu .logo a{
	  text-decoration: none;
	  color: #fff;
	  font-size: 35px;
	  font-weight: 600;
	}
	.menu ul{
	  display: inline-flex;
	}
	.menu ul li{
	  list-style: none;
	  margin-left: 7px;
	}
	.menu ul li:first-child{
	  margin-left: 0px;
	}
	.menu ul li a{
	  text-decoration: none;
	  color: #fff;
	  font-size: 18px;
	  font-weight: 500;
	  padding: 8px 15px;
	  border-radius: 5px;
	  transition: all 0.3s ease;
	}
	.menu ul li a:hover{
	  background: #fff;
	  color: black;
	}
	.img{
	  background: url('img/4.png')no-repeat;
	  width: 100%;
	  height: 100vh;
	  margin: 0% auto;
	  background-size: cover;
	  background-position: center;
	  position: relative;
	}
	.img::before{
	  content: '';
	  position: absolute;
	  height: 100%;
	  width: 100%;
	  background: rgba(0, 0, 0, 0.4);
	}
	.center{
	  position: absolute;
	  top: 52%;
	  left: 50%;
	  transform: translate(-50%, -50%);
	  width: 100%;
	  padding: 0 20px;
	  text-align: center;
	}
	.center .title{
	  color: #fff;
	  font-size: 55px;
	  font-weight: 600;
	}
	.center .sub_title{
	  color: #cd5a5a;
	  font-size: 52px;
	  font-weight: 600;
	}
	.center .btns{
	  margin-top: 20px;
	}
	.center .btns button{
	  height: 55px;
	  width: 170px;
	  border-radius: 5px;
	  border: none;
	  margin: 0 10px;
	  border: 2px solid #cd5a5a;
	  font-size: 20px;
	  font-weight: 500;
	  padding: 0 10px;
	  cursor: pointer;
	  outline: none;
	  transition: all 0.3s ease;
	}
	.center .btns button:first-child{
	  color: #cd5a5a;
	  background: none;
	}
	.btns button:first-child:hover{
	  background: white;
	  color: black;
	}
	
	.center .btns button:last-child{
	  color: #cd5a5a;
	  background: none;
	}
	.btns button:last-child:hover{
	  background: white;
	  color: black;
	}
	
	#demo-text {
		font-size: 5rem;
		font-weight: 700;
		background-clip: text;
		-webkit-background-clip: text;
		color: transparent;
		-webkit-text-stroke-width: 1px;
       -webkit-text-stroke-color: #cd5a5a;
		background-image: url('img/4.png');
	}
	</style>
 
   </head>
<body>
  <div class="img"></div>
  <div class="center">
    <div class="title" id="demo-text">Password Management Tool</div>
    <div class="btns">
      <a href="User"><button>User</button></a>
      <a href="Admin"><button>Admin</button></a>
    </div>
  </div>
</body>
</html>
 