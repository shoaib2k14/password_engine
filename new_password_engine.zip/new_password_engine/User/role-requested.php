<?php
define('TITLE', 'Requested Role');
define('PAGE', 'requested');

include('controller/include.php');

?>
 
 <div class="row">
	<div class="col-12">
		<div class="card">
			<div class="card-body">
				
				<div class="table-responsive">
				   <table class="table align-items-center table-flush data-table" id="dbtable">
					  <thead class="thead-light text-center">
					   <tr>
						  <th scope="col">#</th>
						  <th scope="col">Role</th>
						  <th scope="col">Market</th>
						  <th scope="col">Requested Date</th>
						  <th scope="col">Status</th>
						  <th scope="col" data-orderable="false">Description</th>
						</tr>
					 </thead>
					  
					 <tbody class="text-center">
					  <?php $count = 0;
						while($row = $result->fetch_assoc()){ ?>
						<tr role="row">
						  <td scope="row"><?= ++$count; ?></td>
						  <td><?=$row["role"]; ?></td>
						  <td><?=$row["market"]; ?></td>
						  <td><?=date("d-M-Y",strtotime($row["created_at"])); ?></td>
						  <td>
						    <?php /*if($row["is_approved"] == 1){ echo "Approved"; } if($row["is_declined"] == 1){echo "Rejected";} else {echo "Pending";} */?>
							
							<?php
							  if($row["is_approved"] == 1){?>
							     <span class="badge badge-success w-100 text-white font-bold cursor-pointer blockUnblockDetele">Approved</span>
							<?php } ?>
							
							<?php
							  if($row["is_declined"] == 1){?>
							     <span class="badge badge-primary w-100 text-white font-bold cursor-pointer blockUnblockDetele">Declined</span>
							<?php } ?>
							
							<?php
							  if($row["is_pending"] == 1){?>
							     <span class="badge badge-info w-100 text-white font-bold cursor-pointer blockUnblockDetele">Pending</span>
							<?php } ?>
						  </td>
						  <td><?php echo $row["description"]; ?></td>
						</tr>
					   <?php } ?>
					 </tbody> 
				  </table>
			   </div>
		   </div>
	   </div>
	</div>
 </div>
 
 

<!-- The Modal -->
<div id="getPasswordRequestModal"></div>
<div id="alertMsg"></div>
<!-- Model -->



<?php 
  include('layout/footer.php'); 
  $conn->close();
?>