<?php
include('../../dbConnection.php');

$uEmail = $_SESSION['uEmail'];

$role_id = $_REQUEST['role'];
$server_id = $_REQUEST['server'];
$s_user_id = $_REQUEST['s_user'];


 $sql_mail = "SELECT * FROM mails WHERE status = 1";
 $result_mail = $conn->query($sql_mail);
 $row_mail = mysqli_fetch_assoc($result_mail);
 $mailHost = $row_mail['host'];
 $mailPort = $row_mail['port'];
 $mailUser = $row_mail['user_name'];
 $mailPassword = $row_mail['password'];
 $mailSender = $row_mail['sender'];

$msg = 0;


$sql_u = "SELECT * FROM users WHERE email= '$uEmail'";
	$result_u = $conn->query($sql_u);
	$row_u = $result_u->fetch_assoc();
	$uID = $row_u['id'];
	$uMID = $row_u['market_id'];
	$unix_id = $row_u['unix_id'];
	$uEmail = $row_u['email'];
	$uName = $row_u['f_name'].$row_u['l_name'];


 $sql = "SELECT * from servers Where id = $server_id AND market_id = $uMID";
	 $result = mysqli_query($conn , $sql);
	 $row = mysqli_fetch_assoc($result);
	 $host_name = $row['host_name'];
	 $ip_address = $row['ip_address'];
	 $server_password = decrypt($row['password'], $row['secure_key']);
 
 
 $sql_su = "SELECT user from server_users WHERE id = $s_user_id AND server_id = $server_id";
	$result_su = mysqli_query($conn , $sql_su);
	$row_su = mysqli_fetch_assoc($result_su);
	$sr_user = $row_su['user'];
 
 


/************ For Pdf file creation **************/ 
try{
   /*
	$file_name = date('His-Ymd-').$unix_id.'.pdf';
	$directory = dirname(__FILE__, 3).'/User/public/file/'.$file_name;
	
	$password = rand(100000, 999999);

	require('../pdf/fpdf_protection.php');
	$pdf = new FPDF_Protection();
	$pdf->SetProtection(array('print'), $password); 
	$pdf->AddPage();
	$pdf->SetFont('Arial', 'B', 18);
	$pdf->Cell(100, 12, 'Servers Details', 0);
	$pdf->Ln();
	$pdf->SetFont('Arial', 'B', 12);
	
		$pdf->Cell(32,12, 'Host Name', 1);
		$pdf->Cell(32,12, 'User', 1);
		$pdf->Cell(32,12, 'Ip Address', 1);
		$pdf->Cell(32,12, 'Password', 1);
	
	$pdf->SetFont('Arial', '', 12);
	$pdf->Ln();
	
		$pdf->Cell(32,12, $host_name, 1);
		$pdf->Cell(32,12, $sr_user, 1);
		$pdf->Cell(32,12, $ip_address, 1);
		$pdf->Cell(32,12, $server_password, 1);
	
	//$pdf->Output();
	//$pdf->Output("D","sho.pdf");
	//$obj_pdf->Output($clts."-".$date."-".$time.'.pdf', 'I');
	$pdf->Output("F",$directory);

	
	$sql_i = "INSERT INTO files (user_id, file, password) VALUES('$uID', '$file_name', '$password')";
	$conn->query($sql_i);
	*/
	
	$msg = 1;
	?>
	
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
	<script> 
	  function sendMail() {
			 
			$.ajax({
				//url:'controller/sendMail.php',
				url:'http://139.47.169.69/password-engine/User/controller/sendMail_temp.php',
				type:'POST',
				data: {
					 msg: "sendPDF",
					 uName: "<?php echo $uName; ?>",
					 uEmail: "<?php echo $uEmail; ?>",
					 unix_id: "<?php echo $unix_id; ?>",
					 host_name: "<?php echo $host_name; ?>",
					 sr_user: "<?php echo $sr_user; ?>",
					 ip_address: "<?php echo $ip_address; ?>",
					 server_password: "<?php echo $server_password; ?>",
					 uID: "<?php echo $uID; ?>",
				},
				success:function(result){
					 $('#copyPassword').val(result);
				}
			});
			 
		}
		sendMail();
	</script>
	
	<?php
	 
		/* $htmlbody = 
		    '<html> 
				<body> 
					<h3 style=" text-transform:capitalize;">Hello '.$uName.'</h3> 
					<p>Please find Server details below as a pdf attachment</p>
				</body> 
			 </html>';
			 
		$subject = "Requested server details";


		require('../../phpmailer/PHPMailerAutoload.php');
		
		$mail = new PHPMailer;
		$mail->isSMTP();
		$mail->SMTPDebug = 0;
		$mail->Host = $mailHost;
		$mail->Port = (int)$mailPort;
		
		if(isset($mailUser) && isset($mailPassword)){
		
			$mail->SMTPSecure = 'tls';
			$mail->SMTPAuth = true;
			$mail->Username = $mailUser;
			$mail->Password = $mailPassword;
		}
		
		$mail->setFrom($mailSender);
		$mail->addAddress($uEmail);
        $mail->addAttachment($directory);
		$mail->Subject = $subject;
		$mail->msgHTML($htmlbody);
		
		if (!$mail->send()) {
			echo "Mailer Error: ".$mail->ErrorInfo;
		} */
}

catch(Exception $e){
    $msg = 0;
    //echo 'Message: ' .$e->getMessage();
}


function decrypt($message,$encryption_key){
	$key = $encryption_key;
	$message = base64_decode(urldecode($message));
	$nonceSize = openssl_cipher_iv_length('aes-256-ctr');
	$nonce = mb_substr($message, 0, $nonceSize, '8bit');
	$ciphertext = mb_substr($message, $nonceSize, null, '8bit');

	$plaintext= openssl_decrypt(
	  $ciphertext, 
	  'aes-256-ctr', 
	  $key,
	  OPENSSL_RAW_DATA,
	  $nonce
	);
	
  return $plaintext;
}

?>


<?php
if($msg == 1){?>
	<div id="successMsgModal" class="modal fade delete-modal" role="dialog">
		<div class="modal-dialog modal-dialog-centered">
			<div class="modal-content">
			   <div class="modal-body text-center">
					<i class="fa fa-check-square success_Msg"></i>
					<h5 class="delete_class status_header">Pdf file has sent on your mail</h5>
					<div class="pass">
					  <h4 class="status_content">Get Password:</h4>
					  <input class="fDUSOa dzARff" type="text" value="<?=$password;?>" id="copyPassword">
                      <a onclick="copy()"><i class="fa fa-clone color-gray"></i></a>
					</div>
					
					<p class="status_content">Thanks</p>
					<button type="button" class="btn btn-secondary float-right" onclick="reload()">Close</button>
				</div>
			</div>
		</div>
	</div>
<?php } ?>



<?php
if($msg == 0){?>
	<div id="successMsgModal" class="modal fade delete-modal" role="dialog">
		<div class="modal-dialog modal-dialog-centered">
			<div class="modal-content">
			   <div class="modal-body text-center">
			        <img class="failed_Msg" src="images/sent.png">
			        <!--<i class="fa fa-info-circle failed_Msg"></i>-->
					<h5 class="delete_class status_header">Please try after some time</h5>
					<p class="status_content">Thanks</p>
					<button type="button" class="btn btn-secondary float-right" class="close" data-dismiss="modal">Close</button>
				</div>
			</div>
		</div>
	</div>
<?php } ?>