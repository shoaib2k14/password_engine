<?php
include('../../dbConnection.php');

if($_REQUEST['key']=='updateRequestRole'){
	
	if(($_REQUEST['id'] == '') || ($_REQUEST['value'] == '') || ($_REQUEST['table'] == '') ){
		
		$myObj = new stdClass();
		$myObj->code = 200;
		$myObj->text = "Somthing Went Wrong";
		$myObj->msg = "info";
		$myJSON = json_encode($myObj);
		echo $myJSON;
		die();
	}
	else{
		$id = (int)$_REQUEST['id'];
		$value = $_REQUEST['value'];
		$table = $_REQUEST['table'];
		
		if($value == 'Pending'){
			$status = 0;
		}
		if($value == 'Approve'){
			$status = 1;
		}
		if($value == 'Decline'){
			$status = 2;
		}
		
		if($table == 'Gs'){
			$table = 'grants';
		}
		if($table == 'Su'){
			$table = 'server_users';
		}
		
		$sql = "UPDATE $table SET status='$status' WHERE id = $id ";
		
		
		if($conn->query($sql) === TRUE) {
			$myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = $value." Successfully";
			$myObj->msg = "success";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
			
		} else {
		    $myObj = new stdClass();
		    $myObj->code = 400;
			$myObj->text = "Somthing Went Wrong";
			$myObj->msg = "info";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		    //echo "Error: " . $sql . "<br>" . $conn->error;
		}
	  $conn->close();
	}
} 
?>