<?php
define('TITLE', 'Get Password');
define('PAGE', 'getPassword');

include('controller/include.php');
 
?>
 

 
 <div class="row">
	<div class="col-12">
		<div class="card">
			<div class="card-body">
				
				<div class="table-responsive">
				   <table class="table align-items-center table-flush data-table" id="dbtable">
					  <thead class="thead-light text-center">
					   <tr>
						  <th scope="col">#</th>
						  <th scope="col">File Name</th>
						  <th scope="col">Assigned Date</th>
						  <th scope="col">Expire At</th>
                          <th scope="col" data-orderable="false">Password</th>
						</tr>
					 </thead>
					  
					 <tbody class="text-center">
					  <?php $count = 0;
						while($pRow = $pResult->fetch_assoc()){ ?>
						<tr role="row">
						    <td scope="row"><?php echo ++$count; ?></td>
							<td><?php echo $pRow["file"]; ?></td>
							<td><?php echo $pRow["created_at"]; ?></td>
							<td><?php echo $pRow["expire_at"]; ?></td>
							<td><?php echo $pRow["password"]; ?></td>
						</tr>
					   <?php } ?>
					 </tbody> 
				  </table>
			   </div>
		   </div>
	   </div>
    </div>
 </div>

  
  
  
  


<div class="modal fade delete-modal" id="requestModal" tabindex="-1">
  <div class="modal-dialog">
	<div class="modal-content">

	  <!-- Modal Header -->
	  <div class="modal-header">
		<h4 class="modal-title">Password Request</h4>
		<button type="button" class="close" data-dismiss="modal">&times;</button>
	  </div>

	  <!-- Modal body -->
	  <div class="modal-body">
	  
	   <div class="card mx-2">
		 <div class="card-header"><?php echo $uFName." ".$uLName; ?></div>
		   <div class="card-body">
				<form id="addFormData">
				  <div class="form-group">
					 
					 <label for="server">Select Role</label>
					 <select class="form-control" name="role" id="role" onchange="getServer(this.value)"> 
						  <option value="" disabled selected>Select Role</option> 
							<?php 
							  while($rRow = mysqli_fetch_array($rResult)) { ?> 
								  <option value="<?php echo $rRow['id']; ?>"><?php echo $rRow['role']; ?></option>
						   <?php } ?>				 
					 </select>
					 
					 <div class="mt-3" id="GetServer"></div>
					 
					 <div class="mt-3" id="GetServerUser"></div>
					 
					 
				  </div>
				</form> 
			 </div>
		   </div> 
				 
		   <div class="modal-footer float-right">
		     <button type="button" class="btn btn-primary" id="sendReqButton" onclick="sendFile(this.value)">Request</button>
		     <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
		   </div>
				
		</div>
	  <!-- Modal body end-->
	</div>
  </div>
</div>



<div id="getStatusModal"></div>



<?php 
  include('layout/footer.php'); 
  $conn->close();
?>
