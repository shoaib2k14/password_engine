<?php

$server = $_REQUEST['server'];

/* $connection = ssh2_connect('vgg218yr', 22);
ssh2_auth_password($connection, 'alive007', 'Acc@0323');


if(!$connection){
	echo "Not connected";
}


$stream = ssh2_exec($connection, 'ksh /tmp/scripts/icms1.ksh '.$server);

stream_set_blocking($stream, true);
   $output = ssh2_fetch_stream($stream, SSH2_STREAM_STDIO);
   $message = str_replace(' ','',(stream_get_contents($output))); */
   

$message = "ValidServer";   
   
if(trim($message) == "ValidServer"){
	$myObj = new stdClass();
	$myObj->code = 200;
	$myObj->msg = "Validation Successful";
	$myJSON = json_encode($myObj);
	echo $myJSON;
	die();
}
else{
	$myObj = new stdClass();
	$myObj->code = 400;
	$myObj->msg = "Validation Failed";
	$myJSON = json_encode($myObj);
	echo $myJSON;
	die();
}

    
  

?>