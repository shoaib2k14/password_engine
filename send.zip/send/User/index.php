<?php

define('TITLE', 'User Login');
define('PAGE', 'userLogin');

include('controller/login.php');

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>User Login</title>
  <link rel="shortcut icon" type="image/x-icon" href="../img/logo.png">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="../login/css/bootstrap.min.css">

  <!-- Font Awesome CSS -->
  <link rel="stylesheet" href="../login/css/all.min.css">

  <style>
    .custom-margin {
         margin-top: 8vh;
      }
   </style>
  <title>Login</title>
</head>

<body>
  <div class="mb-3 text-center mt-2 mb-2">
    <!--<i class="fas fa-stethoscope"></i>
    <span>Password Managment System</span>-->
  </div>
  <p class="text-center" style="font-size: 20px; margin-top: 5%;"> <i class="fas fa-user-secret text-danger"></i> <span>User Login</span></p>
  <div class="container-fluid mb-5">
    <div class="row justify-content-center">
      <div class="col-sm-6 col-md-4">
        <form action="" class="shadow-lg p-4" method="POST">
          
		  <div class="form-group">
            <i class="fas fa-user"></i><label for="email" class="pl-2 font-weight-bold">Email</label><input type="email"
              class="form-control" placeholder="Email" name="uEmail">
          </div>
          
		  <div class="form-group">
            <i class="fas fa-key"></i><label for="pass" class="pl-2 font-weight-bold">Password</label><input type="password"
              class="form-control" placeholder="Password" name="uPassword">
          </div>
		  
		  <div class="form-group row">
			<div class="col-md-12">
				<div class="custom-control custom-checkbox">
					<input type="checkbox" class="custom-control-input remember_me" name="remember_me" id="customCheck1">
					<label class="custom-control-label" for="customCheck1"><span>Remember me</span></label>
					<!--<a href="javascript:void(0)" id="to-recover" class="text-dark float-right"><i class="fa fa-lock m-r-5"></i> Forgot password?</a>-->
				</div>
			</div>
		  </div>
		  
          <button type="submit" class="btn btn-outline-danger mt-3 btn-block shadow-sm font-weight-bold">Login</button>
          <?php if(isset($msg)) {echo $msg; } ?>
        </form>
      </div>
    </div>
  </div>

  <!-- Boostrap JavaScript -->
  <script src="../login/js/jquery.min.js"></script>
  <script src="../login/js/popper.min.js"></script>
  <script src="../login/js/bootstrap.min.js"></script>
  <script src="../login/js/all.min.js"></script>
</body>

</html>