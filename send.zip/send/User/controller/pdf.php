<?php
   echo dirname(__FILE__);
   echo "<br>";
   echo __DIR__;
   echo "<br>";
   echo $_SERVER['DOCUMENT_ROOT'];
   echo "<br>";
   echo dirname(__FILE__, 3).'\User\public\file';
   
?>