<?php

$modalName = "addServerUserModal";

include('../controller/modal.php');

?>


<div class="modal fade delete-modal" id="addFormModal">
   <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">

		  <!-- Modal Header -->
		  <div class="modal-header">
			<h4 class="modal-title">Add User</h4>
			<button type="button" class="close" data-dismiss="modal">&times;</button>
		  </div>

		  <!-- Modal body -->
		  <div class="modal-body">
			<form id="addFormData">
				<input type="hidden" class="form-control" type="text" name="sID" value="<?=$sID;?>">
				<input type="hidden" class="form-control" type="text" name="key" value="insertServerUser">
				<div class="row formtype">
				    <div class="col-md-12">
						<div class="form-group">
							<label>User</label>
							<input class="form-control" type="text" name="user">
							<div id="ErrorUser" class="form-control-error"></div>
						</div>
					</div>
					<div class="col-md-12">
					  <div class="form-group">
						<label>Status</label>
						  <select class="form-control" id="status" name="status">
							  <option value="1">Active</option>
							  <option value="0">Inactive</option>
						  </select>
						  <div id="ErrorStatus" class="form-control-error"></div>
					  </div>
					</div>
				  </div>
				</div>
				<div class="modal-footer float-right">
				  <!--<input type="submit" class="btn btn-primary" value="Request"/>-->
				  <button type="submit" class="btn btn-danger" onclick="addOnDB('insertServerUser')">Add</button>
				  <button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
			   </div>
			</form>
		  </div>
		  <!-- Modal body end-->
      </div>
   </div>
</div>

