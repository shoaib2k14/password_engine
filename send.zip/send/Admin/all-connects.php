<?php
$table_name = "connects";
$alert = "";

include('controller/select.php');
include('controller/delete.php');
include('controller/status.php');

?>

<!DOCTYPE html>
<html lang="en">

<?php include("includes/head_link.php"); ?>

<body>
	<!-- Main Wrapper -->
	<div class="main-wrapper">
	
	   <?php include("includes/header.php"); ?>
	   
		<?php include("includes/sidebar.php"); ?>
		
		<!-- Page Wrapper -->
		<div class="page-wrapper">
			<div class="content container-fluid">
				<div class="page-header">
				    <div class="row align-items-center">
						<div class="col-12">
							<div class="mt-5">
								<h4 class="card-title float-left mt-2">PW Connects</h4>
								<a href="add_connection.php" class="btn btn-primary float-right veiwbutton ">Add Connection</a>
							</div>
						</div>
					</div>
					
					<div class="row">
					  <div class="col-12">
					    <?php echo $alert; ?>
					  </div>
					</div>
					
					<div class="row">
					   <div class="col-sm-12">
                          <div class="card card-table">
							 <div class="card-header">
									<h4 class="card-title"></h4>
								</div>
							<div class="card-body booking_card">
								<div class="table-responsive">
									<table class="datatable table table-stripped table table-hover table-center mb-0">
										<thead>
											<tr>
												<th>System</th>
												<th>User</th>
												<th>Password</th>
												<th>Category</th>
												<th>Created_At</th>
												<th>Updated_At</th>
												<th>Status</th>
												<th class="text-right">Actions</th>
											</tr>
										</thead>
										<tbody>
											<?php
												if(1){
													//while($row = oci_fetch($result)){
													while($row = mysqli_fetch_assoc($result)){ ?>
														
														 <tr>
															
															<td><?=$row["SYSTEM"]?></td>
															<td><?=$row["CONNECT_USER"]?></td>
															<td><?=$row["CONNECT_PASSWORD"]?></td>
															<td><?=$row["CATEGORY"]?></td>
															<td><?=$row["CREATED_AT"]?></td>
															<td><?=$row["UPDATED_AT"]?></td>
															
															<td>
															    <form action="" method="POST">
																    <input type="hidden" name="primary_key_update" value="<?=$row["ID"]?>">
																	<button type="submit" name="update_status" class="btn btn-success"><?php echo $row["STATUS"] == 1 ? 'Active' : 'Inactive' ?></button>
																</form>
															</td>
															
															<td class="text-right">
																<div class="dropdown dropdown-action">
																  <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
																   <i class="fa fa-ellipsis-v ellipse_color"></i>
																  </a>
																  
																  <div class="dropdown-menu dropdown-menu-right">
																      <a class="dropdown-item" href="edit_connects.php?id=<?=$row["ID"]?>"><i class="fa fa-pencil m-r-5"></i> Edit
																	  </a>
																	  
																	  <a class="dropdown-item" href="#" data-toggle="modal" data-target="#delete_asset" onclick="myFunction(<?=$row["ID"]?>)">
																	   <i class="fa fa-trash-o m-r-5"></i> Delete
																	  </a>
																  </div>
																  
															    </div>
															</td>
														</tr>
                                               <?php
												  }
                                                }
                                                else{
                                                 echo "No record found";
                                                }
                                              ?>
                                        </tbody>
									</table>
								</div>
							</div>
						</div>
                    </div>
				</div>
			</div>
			
		   <?php include("modal/delete.php"); ?>
			
		</div>
		<!-- /Page Wrapper -->
	</div>
	<!-- /Main Wrapper -->
	
	<!-- jQuery -->
	<script>
		var element = document.getElementById("pwconnects");
		   element.classList.add("active");
		   
		function myFunction(id) {
		   document.getElementById("primary_key_delete").setAttribute('value',id);
		}
    </script>
	
	<?php include("includes/script_link.php"); ?>
	
</body>

</html>