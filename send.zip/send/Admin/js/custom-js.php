<script>
   
   function getForm(key) {
	 //alert(key);
	 $.ajax({
		 url:'modal/addModal.php',
		 type:'POST',
		 data:{
			   key:key,
			 },
		 success:function(result){
			 $('#getFormModal').html(result);
			 $('#successMsgModal').modal('hide');
			 $('#addFormModal').modal('show');
		 }
	 });
   }
   
   function getRoleAssignForm(uID){
	    //alert(key);
		 $.ajax({
			 url:'modal/addGrantModal.php',
			 type:'POST',
			 data:{
				   uID:uID,
				 },
			 success:function(result){
				 $('#getFormModal').html(result);
				 $('#successMsgModal').modal('hide');
				 $('#addFormModal').modal('show');
			 }
		 });
	}
	
	
	function getServerAssignForm(rID){
	    //alert(key);
		 $.ajax({
			 url:'modal/addServerModal.php',
			 type:'POST',
			 data:{
				   rID:rID,
				 },
			 success:function(result){
				 $('#getFormModal').html(result);
				 $('#successMsgModal').modal('hide');
				 $('#addFormModal').modal('show');
			 }
		 });
	}
	
	function getUserAssignForm(sID){
	    //alert(key);
		 $.ajax({
			 url:'modal/addServerUserModal.php',
			 type:'POST',
			 data:{
				   sID:sID,
				 },
			 success:function(result){
				 $('#getFormModal').html(result);
				 $('#successMsgModal').modal('hide');
				 $('#addFormModal').modal('show');
			 }
		 });
	}
   
   function addOnDB(key) {
	 //alert(key);
	 $.ajax({
		 url:'controller/insert.php',
		 type:'POST',
		 data:$('#addFormData').serialize(),
		 success:function(result){
			 //console.log(typeof result);
			 var response = JSON.parse(result);
			 $('.form-control-error').html('');
			 
			 if(response.code != 200){
				 //console.log(response.code);
				 $('#ErrorFName').html(response.f_name);
				 $('#ErrorLName').html(response.l_name);
				 $('#ErrorEmail').html(response.email);
				 $('#ErrorMobile').html(response.mobile);
				 $('#ErrorMarket').html(response.market);
				 $('#ErrorStatus').html(response.status);
				 $('#ErrorRole').html(response.role);
				 $('#ErrorOwner').html(response.owner);
				 $('#ErrorHost').html(response.host);
				 $('#ErrorIp').html(response.ip);
				 $('#ErrorPort').html(response.port);
				 $('#ErrorOs').html(response.os_type);
				 $('#ErrorPassword').html(response.password);
				 $('#ErrorEmployee').html(response.employee_id);
				 $('#ErrorUser').html(response.user);
			 }
			 else{
				 $('#getStatusModal').html(response.msg);
				 $('#addFormModal').modal('hide');
				 $('#successMsgModal').modal('show');
			 }
		}
	 });
   }
   
   
   
   function editForm(id,key) {
	 //alert(key);
	 $.ajax({
		 url:'modal/editModal.php',
		 type:'POST',
		 data:{
			   id:id,
			   key:key,
			 },
		 success:function(result){
			 $('#getFormModal').html(result);
			 $('#successMsgModal').modal('hide');
			 $('#editFormModal').modal('show');
		 }
	 });
   }
   
   function updateOnDB(key) {
	 //alert(key);
	 $.ajax({
		 url:'controller/update.php',
		 type:'POST',
		 data:$('#editFormData').serialize(),
		 success:function(result){
			 //console.log(typeof result);
			 var response = JSON.parse(result);
			 $('.form-control-error').html('');
			 
			 if(response.code != 200){
				 //console.log(response.code);
				 $('#ErrorFName').html(response.f_name);
				 $('#ErrorLName').html(response.l_name);
				 $('#ErrorEmail').html(response.email);
				 $('#ErrorMobile').html(response.mobile);
				 $('#ErrorMarket').html(response.market);
				 $('#ErrorStatus').html(response.status);
				 
				 $('#ErrorRole').html(response.role);
				 $('#ErrorOwner').html(response.owner);
				 $('#ErrorHost').html(response.host);
				 $('#ErrorIp').html(response.ip);
				 $('#ErrorPort').html(response.port);
				 $('#ErrorOs').html(response.os_type);
				 $('#ErrorPassword').html(response.password);
				 $('#ErrorEmployee').html(response.employee_id);
			 }
			 else{
				 $('#getStatusModal').html(response.msg);
				 $('#editFormModal').modal('hide');
				 $('#successMsgModal').modal('show');
			 }
		}
	 });
   }
   
   
   function updateStatusOnDB(id,key,status) {
	 //alert(id+key+status);
	 $.ajax({
		 url:'controller/status.php',
		 type:'POST',
		 data:{
			 id:id,
			 key:key,
			 status:status,
		 },
		 success:function(result){
			 location.reload();
		}
	 });
   }
   
   function deleteAlert(id,name,key) {
		 //document.getElementById("primary_key_delete").setAttribute('value',id);
		 //alert(id + name + key);
		 $.ajax({
		 url:'modal/deleteModal.php',
		 type:'POST',
		 data:{
			   id:id,
			   name:name,
			   key:key,
			 },
		 success:function(result){
			 $('#getFormModal').html(result);
			 $('#successMsgModal').modal('hide');
			 $('#addFormModal').modal('show');
		 }
	   });
     }
	 
    
	function deleteOnDB(id,key){
		 //alert(id + key);
		 $.ajax({
		 url:'controller/delete.php',
		 type:'POST',
		 data:{
			   id:id,
			   key:key,
			 },
		 success:function(result){
			 $('#getStatusModal').html(result);
			 $('#addFormModal').modal('hide');
			 $('#successMsgModal').modal('show');
		 }
	   });
     }
	 
	function getServer(key, owner) {
	 //alert(key);
	 $.ajax({
		 url:'modal/serverModal.php',
		 type:'POST',
		 data:{
			   key:key,
			   owner:owner,
			 },
		 success:function(result){
			 $('#getServerModal').html(result);
			 $('#getserverPerOwner').modal('show');
		 }
	 });
   }
   
    function getRoleAssigned(key, user){
	   //alert(key);
		 $.ajax({
			 url:'modal/grantModal.php',
			 type:'POST',
			 data:{
				   key:key,
				   user:user,
				 },
			 success:function(result){
				 $('#getGrantModal').html(result);
				 $('#getGrantPerUser').modal('show');
			 }
		 });
    }
   
   
   function getConnection(key, role) {
	 //alert(key);
	 $.ajax({
		 url:'modal/connectionModal.php',
		 type:'POST',
		 data:{
			   key:key,
			   role:role,
			 },
		 success:function(result){
			 $('#getConnectionModal').html(result);
			 $('#getconnectionPerRole').modal('show');
		 }
	 });
   }
   
   function getUser(key, server) {
	 //alert(key);
	 $.ajax({
		 url:'modal/userModal.php',
		 type:'POST',
		 data:{
			   key:key,
			   server:server,
			 },
		 success:function(result){
			 $('#getUserModal').html(result);
			 $('#getUserPerServer').modal('show');
		 }
	 });
   }
	 
	function reload(){
		 $('.modal').modal('hide');
		 location.reload();
	 }

</script>