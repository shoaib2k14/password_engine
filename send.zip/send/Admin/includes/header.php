<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
	<title>Vodafone Password Engine</title>

	<!-- Favicon -->
	<link rel="shortcut icon" type="image/x-icon" href="../img/logo.png">

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">

	<!-- Fontawesome CSS -->
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="assets/plugins/datatables/datatables.min.css">
	<!-- Feathericon CSS -->
	<link rel="stylesheet" href="assets/css/feathericon.min.css">

	<link rel="stylesheet" href="assets/plugins/morris/morris.css">

	<!-- Main CSS -->
	<link rel="stylesheet" href="assets/css/style.css">
	
	<style>
	#delete_asset form{
		display:inline-block;
	}
	.form-group {
		margin-bottom: 0rem;
		margin-top: 1rem;
    }
	.modal-body {
		padding: 1rem 2rem;
	}
	.active{
		color: #e60101 !important;
		border-left: 3px solid #e60101;
	}
	
	.sidebar-txt{
		padding:0px;
		font-size:10px;
		margin: 0;
		padding-bottom: 10px;
		/*color: #6c757d;*/
        font-weight: 400;
	}
	.mini-sidebar .sidebar-menu > ul > li > a {
		padding: 0px;
		padding-top: 5px;
	}
	.sidebar-menu {
		padding: 0px 0 0 1px;
	}
	.sidebar-menu > ul > li > a {
		align-items: center;
		border-radius: 8px;
		display: flex;
		justify-content: center;
		padding: 12px 0px;
		position: relative;
		transition: all 0.2s ease-in-out 0s;
	}
	
	.sidebar-menu ul {
		font-size: 15px;
		list-style-type: none;
		padding: 0;
		position: relative;
		margin-right: 0px;
	}
	
	.sidebar-menu li.active a {
		border-radius: 0px;
		color: #e60101 !important;
		box-shadow: 0 7px 12px 0 rgb(95 118 232 / 0%);
		opacity: 1;
		background: #ffffff00;
	}
	
	.sidebar-menu > ul > li {
		margin-bottom: 3px;
		position: relative;
		/*height: 55px;*/
		text-align: center;
	}
	
	.list-divider {
		border-bottom: 1px solid #edf2f9;
		height: 0px !important;
	}
	
	.sidebar {
		background-color: #fff;
		bottom: 0;
		left: 0;
		margin-top: 0;
		position: fixed;
		top: 66px;
		transition: all 0.2s ease-in-out 0s;
		width: 78px;
		z-index: 1001;
	}
	
	.page-wrapper {
		margin-left: 80px;
		padding-top: 32px;
		position: relative;
		transition: all 0.4s ease;
		background-color: #f2f5fa;
	}
	
	.header .header-left {
		float: left;
		height: 65px;
		padding: 0 0px;
		position: relative;
		text-align: center;
		width: 78px;
		background-color: #e84646;
	}
	
	.submenu_class {
		border-left: 1px solid #dfdfdf;
		position: relative;
		margin-left: 0px;
	}
	
	.sidebar-menu ul ul a {
		display: block;
		font-size: 14px;
		padding: 10px 0px 10px 0px;
		position: relative;
		border-top: 1px solid #f0eded;
	}
	
	
	.sidebar-menu ul ul a:before {
		display:none;
	}
	
	.sidebar-menu > ul > li {
		font-size: 10px;
		font-weight: 400;
		margin: 5px 0 0 0;
	}
	
	.sidebar-menu > ul > li > a {
		padding-bottom: 0;
	}
	
	.sidebar-menu > ul > li > a:hover {
		color: #e60101 !important;
		background-color: #e6000000;
	}
	
	.sidebar-menu > ul > li:hover {
		color: #e60101 !important;
        background-color: #e6000000;
	}
	
	.sidebar-menu ul ul a {
		display: block;
		font-size: 14px;
		padding: 10px 0px 0px 0px;
		position: relative;
		border-top: 1px solid #f0eded;
	}
	
	.header {
		left: 0;
		position: fixed;
		right: 0;
		top: 0;
		z-index: 1001;
		height: 65px;
		background-color: #e84646;
		padding: 0 10px 0 0;
		border-bottom: 1px solid #e6010100;
		box-shadow: 0px 2px 8px 1px #887b7b6e;
	}
	
	.user-menu {
		float: right;
		margin: 0px;
		position: relative;
		z-index: 99;
		color: #ffffff;
	}
	
	.user-menu.nav > li > a {
		color: #fff;
	}
	
	.sidebar-menu li a {
       color: #6c757d;
	}
	
	.header .has-arrow .dropdown-toggle:after {
		border-bottom: 2px solid #fff;
		border-right: 2px solid #fff;
	}
	
	.page-titles {
		background: #fff;
		padding: 0px 0px;
		box-shadow: 0 1px 4px 0 rgb(0 0 0 / 10%);
		margin: 0 -31px 0px -31px;
		line-height: 2rem;
		margin-bottom: 2rem;
		border-left: 6px solid #f8f2f2;
		padding-right: 15px;
	}
	
	.page-wrapper > .content {
		padding: 0rem 1.5rem 0;
		margin-top: 35px;
	}
	
	.breadcrumb {
		display: -ms-flexbox;
		display: flex;
		-ms-flex-wrap: wrap;
		flex-wrap: wrap;
		padding: 0.75rem 0rem;
		margin-bottom: 0rem;
		list-style: none;
		background-color: #e9ecef00;
		border-radius: 0rem;
		font-size: 12px;
	}
	
	.text-themecolor{
		font-family: serif;
		font-size: 20px;
		font-weight: bold !important;
		margin: 0 !important;
	}
	
	.breadcrumb-item+.breadcrumb-item {
		padding-left: 0.5rem;
		color: #e60101;
		font-weight: 600;
	}
	
	.slimScrollBar{
		background: rgb(97 89 89) !important;
        width: 4px !important;
	}
	
	.form-control-error{
		font-size:12px;
		text-align:start;
		font-weight:400;
		color:#e84646 !important;
	}
	
	.top-admin{
		line-height: 60px;
		padding: 0px 10px;
	}
	
	@media only screen and (max-width: 991.98px){
		.page-wrapper {
			margin-left: 0 !important;
			padding-left: 0;
			padding-right: 0;
			-webkit-transition: all 0.4s ease;
			-moz-transition: all 0.4s ease;
			transition: all 0.4s ease;
		}
	}
	
	
	/* width */
	::-webkit-scrollbar {
	  width: 4px;
	}

	/* Track */
	::-webkit-scrollbar-track {
	  background: #f1f1f1; 
	}
	 
	/* Handle */
	::-webkit-scrollbar-thumb {
	  background: #888; 
	}

	/* Handle on hover */
	::-webkit-scrollbar-thumb:hover {
	  background: #555; 
	}
	</style>

</head>

<body>
	<!-- Main Wrapper -->
	<div class="main-wrapper">
	
	   <?php include("includes/topbar.php"); ?>
	   
		<?php include("includes/sidebar.php"); ?>