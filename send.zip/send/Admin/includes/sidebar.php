<!-- Sidebar -->
			<div class="sidebar" id="sidebar">
				<div class="sidebar-inner slimscroll">
					<div id="sidebar-menu" class="sidebar-menu">
						<ul>
							
							<li id="dashboard">
								<a href="dashboard.php"><i class="fa fa-dashboard"></i></a>
								<p class="sidebar-txt">Dashboard</p>
							</li>
							<!--<li class="list-divider"></li>-->
	
	                        <?php if($_SESSION['aRole'] == 0){?>
								
								<li id="pwadmins" class="">
									<a href="all-admins.php"><i class="fa fa-suitcase"></i></a>
									<p class="sidebar-txt">Admins</p>
								</li>
								
							<?php } ?>
							
							
							
							<li id="pwusers" class="">
								<a href="all-users.php"><i class="fa fa-suitcase"></i></a>
								<p class="sidebar-txt">Users</p>
							</li>
							
							<!--
								<li id="pwconnects" class="">
									<a href="all-connects.php"><i class="fa fa-user"></i> <span> PW Connects </span> <span
											class="menu-arrow"></span></a>
								</li>
								
								<li id="pwdepartments" class="">
								     <a href="all-departments.php"><i class="fa fa-user"></i> <span> Departments </span> <span
										class="menu-arrow"></span></a>
							    </li>
							
							    <li id="pwpositions" class="">
								      <a href="all-positions.php"><i class="fa fa-user"></i> <span> Positions </span> <span
										class="menu-arrow"></span></a>
							    </li>
							-->
						    <li id="pwroles" class="submenu">
								<a href="#"><i class="fa fa-user"></i><span
										class="menu-arrow"></span></a>
									Roles
								<ul id="pwrole" style="display: none;">
								   <li>
								       <a href="all-roles.php"><i class="fa fa-key"></i></a>
									   <p class="sidebar-txt">Roles</p> 
							       </li>
							
							       <li>
								      <a href="all-roles-requests.php"><i class="fa fa-key"></i></a>
									  <p class="sidebar-txt">Roles Requests</p> 
							       </li>
					            </ul>
							</li>
							
							<!--
							<li id="pwroles" class="">
								<a href="all-roles.php"><i class="fa fa-key"></i> <span> Roles </span> <span
										class="menu-arrow"></span></a>
							</li>
							
							<li id="pwRoleRequested" class="">
								<a href="all-roles-requests.php"><i class="fa fa-key"></i> <span> Roles Requests</span> <span
										class="menu-arrow"></span></a>
							</li>
							-->
							
							<li id="pwmarkets" class="">
								<a href="all-markets.php"><i class="fa fa-user"></i></a>
								<p class="sidebar-txt">Markets</p>
							</li>
							
							
							
							<li id="pwservers" class="submenu">
								<a href="#" id="pwservers"><i class="fa fa-user"></i><span class="menu-arrow"></span></a>
								 Servers 
								<ul style="display: none;">
									<li>
										<a href="all-servers.php"><i class="fa fa-user"></i></a>
										<p class="sidebar-txt">Servers</p> 
									</li>
									
									<li>
										<a href="all-servers-owner.php"><i class="fa fa-user"></i></a>
										<p class="sidebar-txt">Owner </p> 
									</li>
					            </ul>
							</li>
							
							<li class="list-divider"></li>
							<!--
							<li id="pwservers" class="">
								<a href="all-servers.php"><i class="fa fa-user"></i> <span> Servers </span> <span
										class="menu-arrow"></span></a>
							</li>
							
							<li id="pwserversOwner" class="">
								<a href="all-servers-owner.php"><i class="fa fa-user"></i> <span> Servers Owner </span> <span
										class="menu-arrow"></span></a>
							</li>
							-->
							
						</ul>
					</div>
				</div>
			</div>
<!-- /Sidebar -->