<?php
$table_name = "dashboard";

include('controller/select.php');
include("includes/header.php");

?>

<div class="page-wrapper">
    <div class="content container-fluid">
        <div class="page-header">
			<div class="row">
				<div class="col-sm-12 mt-5">
					<h3 class="page-title mt-3"><?php echo $grettings.' '.$admin; ?></h3>
					<!--
					<ul class="breadcrumb">
						<li class="breadcrumb-item active">Dashboard</li>
					</ul>
					-->
				</div>
			</div>
		</div>
		<!-- /Page Header -->
		<div class="row">
			<div class="col-xl-6 col-sm-6 col-12">
				<div class="card board1 fill">
					<div class="card-body">
						<div class="dash-widget-header">
							<div>
								<h3 class="card_widget_header"><?=$total_servers;?></h3>
								<h6 class="text-muted">Total Servers</h6>
							</div>
							<div class="ml-auto mt-md-3 mt-lg-0">
								<span class="opacity-7 text-muted font-size-2rem"><i class="fa fa-paper-plane-o"></i></span>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xl-6 col-sm-6 col-12">
				<div class="card board1 fill">
					<div class="card-body">
						<div class="dash-widget-header">
							<div>
								<h3 class="card_widget_header"><?=$total_users;?></h3>
								<h6 class="text-muted">Total Users</h6>
							</div>
							<div class="ml-auto mt-md-3 mt-lg-0">
								<span class="opacity-7 text-muted font-size-2rem"><i class="fa fa-plug"></i></span>
							</div>
						</div>

					</div>
				</div>
			  </div>
		   </div>
	    </div>
     </div>
  </div>
</div>
	
	
	
<!-- JQuery -->
<?php include("includes/footer.php"); ?>
<script>
	var element = document.getElementById("dashboard");
	   element.classList.add("active");
	   element.classList.add("active");
</script>
