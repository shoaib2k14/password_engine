<?php
$table_name = "changePassword";
$alert = "";

include('controller/select.php');
include("includes/header.php");

?>


<div class="page-wrapper">
	<div class="content container-fluid">
		<div class="page-header">
			<div class="row align-items-center">
				<div class="col-12">
					<div class="mt-5">
						<h4 class="card-title float-left mt-2">Change Password</h4>
					</div>
				</div>
			</div>
			
			<div class="row">
			  <div class="col-12">
				<?php echo $alert; ?>
			  </div>
			</div>
			
			<div class="row">
			   <div class="col-sm-12">
				  <div class="card card-table">
					<div class="card-header">
						<h4 class="card-title"></h4>
					</div>
					
					<div class="card-body booking_card">
					  <form id="resetPassword">
					   <div class="row">	
						 <div class="col-md-6">
						  <div class="form-group">
							<label>Select Server</label>
							  <select class="form-control" name="server">
								  <option selected disabled>Select Server</option>
								  <?php
								   while($row = mysqli_fetch_assoc($result)){?>
								    <option value="<?=$row['id']?>"><?=$row['host_name']?></option>
								  <?php } ?>
							 </select>
						  </div>
					     </div>
					    </div>
						
						<div class="row">
						  <div class="col-md-6">
						    <div class="form-group">
								<label>Password</label>
								<input class="form-control" type="password" name="password">
						    </div>
					      </div>
						</div>
					  </form>
					  
						<div class="row mt-4">
						  <div class="col-md-6">
						   <button type="resetPassword" class="btn btn-secondary mr-3">Reset</button>
						   <button type="submit" class="btn btn-primary" onclick="resetPassword()">Update</button>
						  </div>
						</div>
					   
					</div>
				 </div>
			 </div>
		  </div>
	  </div>
   </div>
</div>
	
	
	
<!-- Modal's -->
 <div id="getUserModal"></div>
 <div id="getFormModal"></div>
 <div id="getStatusModal"></div>
<!-- Model's -->


<!-- jQuery -->
<script>
	var element = document.getElementById("changePassword");
	   element.classList.add("active");
	
</script>
<?php include("includes/footer.php"); ?>
	
