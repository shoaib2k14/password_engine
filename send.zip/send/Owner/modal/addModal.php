<?php

$modalName = "addModal";

include('../controller/modal.php');

?>


<?php
if($key == 'addAdmin'){?>
	<div class="modal fade delete-modal" id="addFormModal">
	  <div class="modal-dialog modal-dialog-centered modal-lg">
		<div class="modal-content">

		  <!-- Modal Header -->
		  <div class="modal-header">
			<h4 class="modal-title">Add Admin</h4>
			<button type="button" class="close" data-dismiss="modal">&times;</button>
		  </div>

		  <!-- Modal body -->
		  <div class="modal-body">
			<form id="addFormData">
				<input type="hidden" class="form-control" type="text" name="key" value="insertAdmin">
				<div class="row formtype">
					<div class="col-md-6">
						<div class="form-group">
							<label>First Name</label>
							<input class="form-control" type="text" name="f_name">
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>Last Name</label>
							<input class="form-control" type="text" name="l_name">
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>Email</label>
							<input class="form-control" type="email" name="email">
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>Mobile Number</label>
							<input class="form-control" type="number" name="mobile">
						</div>
					</div>
					<div class="col-md-6">
					  <div class="form-group">
						<label>Status</label>
						  <select class="form-control" id="status" name="status">
							  <option value="1">Active</option>
							  <option value="0">Inactive</option>
						  </select>
					  </div>
					</div>
				  </div>
				</div>
				<div class="modal-footer float-right">
				  <!--<input type="submit" class="btn btn-primary" value="Request"/>-->
				  <button type="submit" class="btn btn-primary" onclick="addOnDB('insertAdmin')">Add</button>
				  <button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
			   </div>
			</form>
		  </div>
		  <!-- Modal body end-->
		</div>
	   </div>
	 </div>
<?php } ?>





<?php
if($key == 'addRole'){?>
	<div class="modal fade delete-modal" id="addFormModal">
	  <div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">

		  <!-- Modal Header -->
		  <div class="modal-header">
			<h4 class="modal-title">Add Role</h4>
			<button type="button" class="close" data-dismiss="modal">&times;</button>
		  </div>

		  <!-- Modal body -->
		  <div class="modal-body">
			<form id="addFormData">
				<input type="hidden" class="form-control" type="text" name="key" value="insertRole">
				<div class="row formtype">
					<div class="col-md-12">
						<div class="form-group">
							<label>Role</label>
							<input class="form-control" type="text" name="role">
						</div>
					</div>
					<div class="col-md-12">
					  <div class="form-group">
						<label>Status</label>
						  <select class="form-control" id="status" name="status">
							  <option value="1">Active</option>
							  <option value="0">Inactive</option>
						  </select>
					  </div>
					</div>
				  </div>
				</div>
				<div class="modal-footer float-right">
				  <!--<input type="submit" class="btn btn-primary" value="Request"/>-->
				  <button type="submit" class="btn btn-primary" onclick="addOnDB('insertRole')">Add</button>
				  <button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
			   </div>
			</form>
		  </div>
		  <!-- Modal body end-->
		</div>
	   </div>
	 </div>
<?php } ?>






<?php
if($key == 'addMarket'){?>
	<div class="modal fade delete-modal" id="addFormModal">
	  <div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">

		  <!-- Modal Header -->
		  <div class="modal-header">
			<h4 class="modal-title">Add Market</h4>
			<button type="button" class="close" data-dismiss="modal">&times;</button>
		  </div>

		  <!-- Modal body -->
		  <div class="modal-body">
			<form id="addFormData">
				<input type="hidden" class="form-control" type="text" name="key" value="insertMarket">
				<div class="row formtype">
					<div class="col-md-12">
						<div class="form-group">
							<label>Market</label>
							<input class="form-control" type="text" name="market">
						</div>
					</div>
					<div class="col-md-12">
					  <div class="form-group">
						<label>Status</label>
						  <select class="form-control" id="status" name="status">
							  <option value="1">Active</option>
							  <option value="0">Inactive</option>
						  </select>
					  </div>
					</div>
				  </div>
				</div>
				<div class="modal-footer float-right">
				  <!--<input type="submit" class="btn btn-primary" value="Request"/>-->
				  <button type="submit" class="btn btn-primary" onclick="addOnDB('insertMarket')">Add</button>
				  <button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
			   </div>
			</form>
		  </div>
		  <!-- Modal body end-->
		</div>
	   </div>
	 </div>
<?php } ?>





<?php
if($key == 'addOwner'){?>
	<div class="modal fade delete-modal" id="addFormModal">
	  <div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">

		  <!-- Modal Header -->
		  <div class="modal-header">
			<h4 class="modal-title">Add Owner</h4>
			<button type="button" class="close" data-dismiss="modal">&times;</button>
		  </div>

		  <!-- Modal body -->
		  <div class="modal-body">
			<form id="addFormData">
				<input type="hidden" class="form-control" type="text" name="key" value="insertOwner">
				<div class="row formtype">
					<div class="col-md-12">
						<div class="form-group">
							<label>Owner</label>
							<input class="form-control" type="text" name="owner">
						</div>
					</div>
					<div class="col-md-12">
						<div class="form-group">
							<label>Email</label>
							<input class="form-control" type="email" name="email">
						</div>
					</div>
					<div class="col-md-12">
					  <div class="form-group">
						<label>Status</label>
						  <select class="form-control" id="status" name="status">
							  <option value="1">Active</option>
							  <option value="0">Inactive</option>
						  </select>
					  </div>
					</div>
				  </div>
				</div>
				<div class="modal-footer float-right">
				  <!--<input type="submit" class="btn btn-primary" value="Request"/>-->
				  <button type="submit" class="btn btn-primary" onclick="addOnDB('insertOwner')">Add</button>
				  <button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
			   </div>
			</form>
		  </div>
		  <!-- Modal body end-->
		</div>
	   </div>
	 </div>
<?php } ?>



<?php
if($key == 'addServer'){
	
	$sql_owner = "SELECT id,owner FROM server_owners WHERE status = 1 ORDER BY owner";
	$result_owner = $conn->query($sql_owner);
	
	?>
	<div class="modal fade delete-modal" id="addFormModal">
	  <div class="modal-dialog modal-dialog-centered modal-lg">
		<div class="modal-content">

		  <!-- Modal Header -->
		  <div class="modal-header">
			<h4 class="modal-title">Add Server</h4>
			<button type="button" class="close" data-dismiss="modal">&times;</button>
		  </div>

		  <!-- Modal body -->
		  <div class="modal-body">
			<form id="addFormData">
				<input type="hidden" class="form-control" type="text" name="key" value="insertServer">
				<div class="row formtype">
				    <div class="col-md-6">
						<div class="form-group">
							<label>Select Owner</label>
							<select class="form-control" name="owner">
								<option value="" disabled selected>Select Owner</option>
								  <?php while($row_owner = $result_owner->fetch_assoc()){ ?>  
									<option value="<?php echo $row_owner['id']; ?>"> <?php echo $row_owner['owner']; ?> </option>  
								  <?php }?>
							</select>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>User</label>
							<input class="form-control" type="text" name="user">
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>Host</label>
							<input class="form-control" type="text" name="host">
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>Ip</label>
							<input class="form-control" type="text" name="ip">
						</div>
					</div>
					<div class="col-md-6">
					  <div class="form-group">
						<label>Os Type</label>
						  <select class="form-control" name="os_type">
							  <option value="windows">Windows</option>
							  <option value="linux">Linux</option>
						  </select>
					  </div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>Password</label>
							<input class="form-control" type="password" name="password">
						</div>
					</div>
					<div class="col-md-6">
					  <div class="form-group">
						<label>Status</label>
						  <select class="form-control" id="status" name="status">
							  <option value="1">Active</option>
							  <option value="0">Inactive</option>
						  </select>
					  </div>
					</div>
				  </div>
				</div>
				<div class="modal-footer float-right">
				  <!--<input type="submit" class="btn btn-primary" value="Request"/>-->
				  <button type="submit" class="btn btn-primary" onclick="addOnDB('insertServer')">Add</button>
				  <button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
			   </div>
			</form>
		  </div>
		  <!-- Modal body end-->
		</div>
	   </div>
	 </div>
<?php } ?>




<?php
if($key == 'addUser'){
	
	$mSql= "SELECT id,market FROM markets WHERE status = 1 ORDER BY market";
	$mResult = $conn->query($mSql);
	
	?>
	<div class="modal fade delete-modal" id="addFormModal">
	  <div class="modal-dialog modal-dialog-centered modal-lg">
		<div class="modal-content">

		  <!-- Modal Header -->
		  <div class="modal-header">
			<h4 class="modal-title">Add User</h4>
			<button type="button" class="close" data-dismiss="modal">&times;</button>
		  </div>

		  <!-- Modal body -->
		  <div class="modal-body">
			<form id="addFormData">
				<input type="hidden" class="form-control" type="text" name="key" value="insertUser">
				<div class="row formtype">
				    <div class="col-md-12">
						<div class="form-group">
							<label>Select Market</label>
							<select class="form-control" name="market">
								<option value="" disabled selected>Select Market</option>
								  <?php while($mRow = $mResult->fetch_assoc()){ ?>  
									<option value="<?php echo $mRow['id']; ?>"> <?php echo $mRow['market']; ?> </option>  
								  <?php }?>
							</select>
						</div>
					</div>
				    <div class="col-md-6">
						<div class="form-group">
							<label>Employee ID</label>
							<input class="form-control" type="text" name="employee_id">
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>First Name</label>
							<input class="form-control" type="text" name="f_name">
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>Last Name</label>
							<input class="form-control" type="text" name="l_name">
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>Email</label>
							<input class="form-control" type="email" name="email">
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>Mobile</label>
							<input class="form-control" type="text" name="mobile">
						</div>
					</div>
				    <div class="col-md-6">
					  <div class="form-group">
						<label>Status</label>
						  <select class="form-control" id="status" name="status">
							  <option value="1">Active</option>
							  <option value="0">Inactive</option>
						  </select>
					  </div>
					</div>
				  </div>
				</div>
				<div class="modal-footer float-right">
				  <!--<input type="submit" class="btn btn-primary" value="Request"/>-->
				  <button type="submit" class="btn btn-primary" onclick="addOnDB('insertUser')">Add</button>
				  <button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
			   </div>
			</form>
		  </div>
		  <!-- Modal body end-->
		</div>
	   </div>
	 </div>
<?php } ?>
