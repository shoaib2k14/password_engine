<!-- Sidebar -->
			<div class="sidebar" id="sidebar">
				<div class="sidebar-inner slimscroll">
					<div id="sidebar-menu" class="sidebar-menu">
						<ul>
							
							<li id="dashboard">
								<a href="dashboard.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a>
							</li>
							<li class="list-divider"></li>
	
	                        <li id="pwservers" class="">
								<a href="all-servers.php"><i class="fa fa-user"></i> <span> Servers </span> <span
										class="menu-arrow"></span></a>
							</li>
							
							<li id="changePassword" class="">
								<a href="change-Password.php"><i class="fa fa-user"></i> <span> Change Password </span> <span
										class="menu-arrow"></span></a>
							</li>
							
						</ul>
					</div>
				</div>
			</div>
<!-- /Sidebar -->