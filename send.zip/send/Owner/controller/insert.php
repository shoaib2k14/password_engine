<?php
include('../../dbConnection.php');

$msg = "";


if($_REQUEST['key']=='insertAdmin'){
	
	if(($_REQUEST['f_name'] == '') || ($_REQUEST['l_name'] == '') || ($_REQUEST['email'] == '') || ($_REQUEST['mobile'] == '') || ($_REQUEST['status'] == '')){
		
		$msg = 1; //"Please fill all the fields";
	}
	else{
		$f_name = $_REQUEST['f_name'];
		$l_name = $_REQUEST['l_name'];
		$email = $_REQUEST['email'];
		$mobile = $_REQUEST['mobile'];
		$pass = rand (100,999);
		$status = $_REQUEST['status'];
		//$created_at = "";
		
		$sql = "INSERT INTO admins (f_name, l_name, email, mobile, password, status) VALUES('$f_name', '$l_name', '$email', '$mobile', '$pass', '$status')";
		
		if($conn->query($sql) === TRUE) {
		   $msg = 2; //"Inserted Successfully";
		} else {
		   $msg = 3; //"Somthing Went Wrong";
		   
		   //echo "Error: " . $sql . "<br>" . $conn->error;
		}

		$conn->close();
	
	}
} 



if($_REQUEST['key']=='insertRole'){
	
	if(($_REQUEST['role'] == '') || ($_REQUEST['status'] == '')){
		
		$msg = 1; //"Please fill all the fields";
	}
	else{
		$role = $_REQUEST['role'];
		$status = $_REQUEST['status'];
		//$created_at = "";
		
		$sql = "INSERT INTO roles (role, status) VALUES('$role', '$status')";
		
		if($conn->query($sql) === TRUE) {
		   $msg = 2; //"Inserted Successfully";
		} else {
		   $msg = 3; //"Somthing Went Wrong";
		   
		   //echo "Error: " . $sql . "<br>" . $conn->error;
		}

		$conn->close();
	
	}
} 


if($_REQUEST['key']=='insertMarket'){
	
	if(($_REQUEST['market'] == '') || ($_REQUEST['status'] == '')){
		
		$msg = 1; //"Please fill all the fields";
	}
	else{
		$market = $_REQUEST['market'];
		$status = $_REQUEST['status'];
		//$created_at = "";
		
		$sql = "INSERT INTO markets (market, status) VALUES('$market', '$status')";
		
		if($conn->query($sql) === TRUE) {
		   $msg = 2; //"Inserted Successfully";
		} else {
		   $msg = 3; //"Somthing Went Wrong";
		   
		   //echo "Error: " . $sql . "<br>" . $conn->error;
		}

		$conn->close();
	
	}
} 



if($_REQUEST['key']=='insertOwner'){
	
	if(($_REQUEST['owner'] == '') || ($_REQUEST['email'] == '') || ($_REQUEST['status'] == '')){
		
		$msg = 1; //"Please fill all the fields";
	}
	else{
		$owner = $_REQUEST['owner'];
		$email = $_REQUEST['email'];
		$status = $_REQUEST['status'];
		//$created_at = "";
		
		$sql = "INSERT INTO server_owners (owner, email, status) VALUES('$owner', '$email', '$status')";
		
		if($conn->query($sql) === TRUE) {
		   $msg = 2; //"Inserted Successfully";
		} else {
		   $msg = 3; //"Somthing Went Wrong";
		   
		   //echo "Error: " . $sql . "<br>" . $conn->error;
		}

		$conn->close();
	
	}
} 


if($_REQUEST['key']=='insertServer'){
	
	if(($_REQUEST['owner'] == '') || ($_REQUEST['user'] == '') || ($_REQUEST['host'] == '') || ($_REQUEST['os_type'] == '') || ($_REQUEST['ip'] == '') || ($_REQUEST['password'] == '') || ($_REQUEST['status'] == '')){
		 
		$msg = 1; //"Please fill all the fields";
	}
	else{
		$owner_id = $_REQUEST['owner'];
		$user = $_REQUEST['user'];
		$host = $_REQUEST['host'];
		$ip = $_REQUEST['ip'];
		$os_type = $_REQUEST['os_type'];
		$password = $_REQUEST['password'];
		$status = $_REQUEST['status'];
		//$created_at = "";
		
		$sql = "INSERT INTO servers (owner_id, user, host_name, ip_address, os_type, password, status) VALUES('$owner_id', '$user', '$host', '$ip', '$os_type', '$password', '$status')";
		
		
		if($conn->query($sql) === TRUE) {
		   $msg = 2; //"Inserted Successfully";
		} else {
		   
		   $msg = 3; //"Somthing Went Wrong";
		   
		   //echo "Error: " . $sql . "<br>" . $conn->error;
		}

		$conn->close();
	
	}
} 



if($_REQUEST['key']=='insertUser'){
	
	if(($_REQUEST['employee_id'] == '') || ($_REQUEST['f_name'] == '') || ($_REQUEST['l_name'] == '') || ($_REQUEST['email'] == '') || ($_REQUEST['mobile'] == '') || ($_REQUEST['market'] == '') || ($_REQUEST['status'] == '')){
		 
		$msg = 1; //"Please fill all the fields";
	}
	else{
		$employee_id = $_REQUEST['employee_id'];
		$f_name = $_REQUEST['f_name'];
		$l_name = $_REQUEST['l_name'];
		$email = $_REQUEST['email'];
		$mobile = $_REQUEST['mobile'];
		$market_id = $_REQUEST['market'];
		$status = $_REQUEST['status'];
		$password = rand (100,999);
		//$created_at = "";
		
		$sql = "INSERT INTO users (employee_id, market_id, f_name, l_name, email, mobile, password, status) VALUES('$employee_id', '$market_id','$f_name', '$l_name', '$email', '$mobile', '$password', '$status')";
		
		
		if($conn->query($sql) === TRUE) {
			$msg = 2; //"Inserted Successfully";
		} else {
		   
		   $msg = 3; //"Somthing Went Wrong";
		   
		   echo "Error: " . $sql . "<br>" . $conn->error;
		}

		$conn->close();
	
	}
} 





/*

if(isset($_REQUEST['insert_user'])){
	if(($_REQUEST['f_name'] == '') || ($_REQUEST['l_name'] == '') || ($_REQUEST['email'] == '') || ($_REQUEST['phone'] == '') || ($_REQUEST['mobile'] == '') || ($_REQUEST['company'] == '') || ($_REQUEST['department'] == '') || ($_REQUEST['position'] == '')){
		$alert = '<div class="alert alert-warning col-sm-12" role="alert"> Please fill all the fields </div>';
	}
	else{
		$f_name = $_REQUEST['f_name'];
		$l_name = $_REQUEST['l_name'];
		$email = $_REQUEST['email'];
		$phone = $_REQUEST['phone'];
		$mobile = $_REQUEST['mobile'];
		$company = $_REQUEST['company'];
		$department = $_REQUEST['department'];
		$position = $_REQUEST['position'];
		$date = $_REQUEST['date'];
		$status = $_REQUEST['status'];;
		
		$sql = 'INSERT INTO pwuser (FIRST_NAME, LAST_NAME, EMAIL, PHONE, MOBILE, COMPANY, DEPARTMENT, POSITION, STATUS) VALUES(:f_name, :l_name, :email, :phone, :mobile, :company, :department, :position, :status)';
		
		$parse = oci_parse($connection, $sql);
		
		
		oci_bind_by_name($parse, ':f_name', $f_name);
		oci_bind_by_name($parse, ':l_name', $l_name);
		oci_bind_by_name($parse, ':email', $email);
		oci_bind_by_name($parse, ':phone', $phone);
		oci_bind_by_name($parse, ':mobile', $mobile);
		oci_bind_by_name($parse, ':company', $company);
		oci_bind_by_name($parse, ':department', $department);
		oci_bind_by_name($parse, ':position', $position);
		//oci_bind_by_name($parse, ':date', $date);
		oci_bind_by_name($parse, ':status', $status);
		
		$execute = oci_execute($parse);
		
		if($execute){
			$alert = '<div class="alert alert-success col-sm-12" role="alert"> Inserted successfully </div>';
		}
		else{
			$alert = '<div class="alert alert-danger col-sm-12" role="alert"> Somthing went wrong </div>';
		}
		
		oci_free_statement($parse);
		oci_close($connection);
	}
}




if(isset($_REQUEST['insert_role'])){
	if(($_REQUEST['name'] == '') || ($_REQUEST['description'] == '') || ($_REQUEST['status'] == '')){
		$alert = '<div class="alert alert-warning col-sm-12" role="alert"> Please fill all the fields </div>';
	}
	else{
		$name = $_REQUEST['name'];
		$description = $_REQUEST['description'];
		$status = $_REQUEST['status'];
		
		$sql = 'INSERT INTO pwroles (NAME, DESCRIPTION, STATUS) VALUES(:name, :description, :status)';
		
		$parse = oci_parse($connection, $sql);
		
		
		oci_bind_by_name($parse, ':name', $name);
		oci_bind_by_name($parse, ':description', $description);
		oci_bind_by_name($parse, ':status', $status);
		
		$execute = oci_execute($parse);
		
		if($execute){
			$alert = '<div class="alert alert-success col-sm-12" role="alert"> Inserted successfully </div>';
		}
		else{
			$alert = '<div class="alert alert-danger col-sm-12" role="alert"> Somthing went wrong </div>';
		}
		
		oci_free_statement($parse);
		oci_close($connection);
	}
}

if(isset($_REQUEST['insert_group'])){
	if(($_REQUEST['name'] == '') || ($_REQUEST['description'] == '') || ($_REQUEST['status'] == '')){
		$alert = '<div class="alert alert-warning col-sm-12" role="alert"> Please fill all the fields </div>';
	}
	else{
		$name = $_REQUEST['name'];
		$description = $_REQUEST['description'];
		$status = $_REQUEST['status'];
		
		$sql = 'INSERT INTO pwgroups (NAME, DESCRIPTION, STATUS) VALUES(:name, :description, :status)';
		
		$parse = oci_parse($connection, $sql);
		
		
		oci_bind_by_name($parse, ':name', $name);
		oci_bind_by_name($parse, ':description', $description);
		oci_bind_by_name($parse, ':status', $status);
		
		$execute = oci_execute($parse);
		
		if($execute){
			$alert = '<div class="alert alert-success col-sm-12" role="alert"> Inserted successfully </div>';
		}
		else{
			$alert = '<div class="alert alert-danger col-sm-12" role="alert"> Somthing went wrong </div>';
		}
		
		oci_free_statement($parse);
		oci_close($connection);
	}
}


if(isset($_REQUEST['insert_connection'])){
	if(($_REQUEST['system'] == '') || ($_REQUEST['user'] == '') || ($_REQUEST['password'] == '') || ($_REQUEST['category'] == '') || ($_REQUEST['status'] == '')){
		$alert = '<div class="alert alert-warning col-sm-12" role="alert"> Please fill all the fields </div>';
	}
	else{
		$system = $_REQUEST['system'];
		$user = $_REQUEST['user'];
		$password = $_REQUEST['password'];
		$category = $_REQUEST['category'];
		$status = $_REQUEST['status'];
		
		$sql = 'INSERT INTO pwconnects (SYSTEM, CONNECT_USER, CONNECT_PASSWORD, CATEGORY, STATUS) VALUES(:system, :user, :password, :category, :status)';
		
		$parse = oci_parse($connection, $sql);
		
		
		oci_bind_by_name($parse, ':system', $system);
		oci_bind_by_name($parse, ':user', $user);
		oci_bind_by_name($parse, ':password', $password);
		oci_bind_by_name($parse, ':category', $category);
		oci_bind_by_name($parse, ':status', $status);
		
		$execute = oci_execute($parse);
		
		if($execute){
			$alert = '<div class="alert alert-success col-sm-12" role="alert"> Inserted successfully </div>';
		}
		else{
			$alert = '<div class="alert alert-danger col-sm-12" role="alert"> Somthing went wrong </div>';
		}
		
		oci_free_statement($parse);
		oci_close($connection);
	}
}

*/

?>





<?php
if($msg == 1){?>
 <div id="successMsgModal" class="modal fade delete-modal" role="dialog">
	<div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">
		   <div class="modal-body text-center">
			    <button type="button" class="close" data-dismiss="modal">&times;</button>
				<img src="assets/img/sent.png" alt="" width="50" height="46">
				<h3 class="delete_class">Please fill all the fields</h3>
				<div class="m-t-20"> 
				    <button class="btn btn-primary veiwbutton " onclick="addAdmin('addAdmin')">Add Admin</button>
					<a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
				</div>
			</div>
		</div>
	</div>
</div>
<?php } ?>


<?php
if($msg == 2){?>
 <div id="successMsgModal" class="modal fade delete-modal" role="dialog">
	<div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">
		   <div class="modal-body text-center">
			    <button type="button" class="close" data-dismiss="modal" onclick="reload()">&times;</button>
				<img src="assets/img/sent.png" alt="" width="50" height="46">
				<h3 class="delete_class">Inserted Successfully</h3>
				<div class="m-t-20"> 
				    <button class="btn btn-primary veiwbutton " onclick="addAdmin('addAdmin')">Add Admin</button>
					<a href="#" class="btn btn-white" data-dismiss="modal" onclick="reload()">Close</a>
				</div>
			</div>
		</div>
	</div>
</div>
<?php } ?>


<?php
if($msg == 3){?>
 <div id="successMsgModal" class="modal fade delete-modal" role="dialog">
	<div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">
		   <div class="modal-body text-center">
			    <button type="button" class="close" data-dismiss="modal">&times;</button>
				<img src="assets/img/sent.png" alt="" width="50" height="46">
				<h3 class="delete_class">Somthing Went Wrong</h3>
				<div class="m-t-20"> 
				    <button class="btn btn-primary veiwbutton " onclick="addAdmin('addAdmin')">Add Admin</button>
					<a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
				</div>
			</div>
		</div>
	</div>
</div>
<?php } ?>




<?php
if($msg == 4){?>
 <div id="successMsgModal" class="modal fade delete-modal" role="dialog">
	<div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">
		   <div class="modal-body text-center">
			    <button type="button" class="close" data-dismiss="modal">&times;</button>
				<img src="assets/img/sent.png" alt="" width="50" height="46">
				<h3 class="delete_class">Undefined error please try after some time</h3>
				<div class="m-t-20"> 
				    <button class="btn btn-primary veiwbutton " onclick="addAdmin('addAdmin')">Add Admin</button>
					<a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
				</div>
			</div>
		</div>
	</div>
</div>
<?php } ?>

