<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start(); 

$username = "SYSTEM";
$password = "S456l@qw";
$dbname = "139.47.169.67/PWEngine";

 

//$conn = oci_connect($username, $password, $dbname);

$conn = mysqli_connect("localhost","root","","password_engine") or die(mysql_error());

 

if(!$conn){
    echo "somthing wrong";
}
 

?>