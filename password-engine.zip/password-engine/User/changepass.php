<?php
define('TITLE', 'Change Password');
define('PAGE', 'changepass');

include('../dbConnection.php');
include('includes/header.php'); 

 if(isset($_SESSION['is_user_login'])){
  $uEmail = $_SESSION['uEmail'];
 } else {
  echo "<script> location.href='index.php'; </script>";
 }
 
 $uEmail = $_SESSION['uEmail'];
 
 if(isset($_REQUEST['passupdate'])){
  
  if(($_REQUEST['old_Password'] == "") || ($_REQUEST['new_Password'] == "") || ($_REQUEST['confirm_Password'] == "")){
   $passmsg = '<div class="alert alert-warning col-sm-6 ml-5 mt-2" role="alert"> Fill All Fileds </div>';
  }
  else {
    $sql = "SELECT * FROM users WHERE email='$uEmail'";
    $result = $conn->query($sql);
	$row = $result->fetch_assoc();
    
	if($result->num_rows == 1){
		
		if($_REQUEST['old_Password'] != $row['password']){
			$passmsg = '<div class="alert alert-warning col-sm-6 ml-5 mt-2" role="alert"> Old password not matched </div>';
		}
		if($_REQUEST['new_Password'] != $_REQUEST['confirm_Password']){
			$passmsg = '<div class="alert alert-warning col-sm-6 ml-5 mt-2" role="alert"> New & Confirm password not matched </div>';
		}
		else{
			$sql = "UPDATE users SET password = '$_REQUEST[confirm_Password]' WHERE email = '$uEmail'";
			
			if($conn->query($sql) == TRUE){
			   $passmsg = '<div class="alert alert-success col-sm-6 ml-5 mt-2" role="alert"> Updated Successfully </div>';
			 }else {
			   $passmsg = '<div class="alert alert-danger col-sm-6 ml-5 mt-2" role="alert"> Unable to Update </div>';
			  }
		}
     }
  }
}
?>
<div class="col-sm-9 col-md-10">
  <div class="row">
    <div class="col-sm-6">
      <form class="mt-5 mx-5">
		<div class="form-group">
          <label for="old_Password">Old Password</label>
          <input type="password" class="form-control" id="old_Password" placeholder="Old Password" name="old_Password">
        </div>
		<div class="form-group">
          <label for="new_Password">New Password</label>
          <input type="password" class="form-control" id="new_Password" placeholder="New Password" name="new_Password">
        </div>
        <div class="form-group">
          <label for="confirm_Password">Confirm Password</label>
          <input type="password" class="form-control" id="confirm_Password" placeholder="Confirm Password" name="confirm_Password">
        </div>
        <button type="submit" class="btn btn-danger mr-4 mt-4" name="passupdate">Update</button>
        <button type="reset" class="btn btn-secondary mt-4">Reset</button>
        <?php if(isset($passmsg)) {echo $passmsg; } ?>
      </form>
    </div>
  </div>
</div>
</div>
</div>
<?php
include('includes/footer.php'); 
?>