<?php
define('TITLE', 'Request Role');
define('PAGE', 'requested');

include('../dbConnection.php');
include('includes/header.php'); 


 if(isset($_SESSION['is_user_login'])){
    $uEmail = $_SESSION['uEmail'];
	
	$sql_market = "SELECT id,market FROM markets WHERE status = 1";
	$result_market = $conn->query($sql_market);
	
	$sql_role = "SELECT id,role FROM roles WHERE status = 1";
	$result_role = $conn->query($sql_role);
	
	$sql_emp = "SELECT employee_id,id FROM users WHERE email = '$uEmail' and status = 1 limit 1";
	$result_emp = $conn->query($sql_emp);
	$row_emp = $result_emp->fetch_assoc();
	$user_id = $row_emp['id'];
	
	  
 } else {
  echo "<script> location.href='login.php'; </script>";
 }
 
 
if(isset($_REQUEST['psubmit'])){
 // Checking for Empty Fields
 if(($_REQUEST['role'] == "") || ($_REQUEST['market'] == "")){
  // msg displayed if required field missing
  $msg = '<div class="alert alert-warning col-sm-6 ml-5 mt-2" role="alert"> Fill All Fileds </div>';
 } else {
  // Assigning User Values to Variable
  $role_id = $_REQUEST['role'];
  $market_id = $_REQUEST['market'];
 
   $sql = "INSERT INTO role_requests (user_id, role_id, market_id) VALUES ('$user_id', '$role_id','$market_id')";
   if($conn->query($sql) == TRUE){
    // below msg display on form submit success
    $msg = '<div class="alert alert-success col-sm-6 ml-5 mt-2" role="alert"> Requested Successfully </div>';
    echo "<script> location.href='role-requested.php'; </script>";
   } else {
    // below msg display on form submit failed
    $msg = '<div class="alert alert-danger col-sm-6 ml-5 mt-2" role="alert"> Unable to Request </div>';
   }
 }
 }
?>
<div class="col-sm-6 mt-5  mx-3 jumbotron">
  <h3 class="text-center">Request For New Role</h3>
  <form action="" method="POST">
    <div class="form-group">
      <label for="id">Employee Id</label>
      <input type="text" class="form-control" id="id" name="id" value="<?php echo $row_emp['employee_id']; ?>" readonly>
    </div>
    <div class="form-group">  
      <label for="market">Market</label>
      <select class="form-control" name="market" id="market">
		<option value="" disabled selected>--- Choose Market ---</option>
		  <?php while($row_market = $result_market->fetch_assoc()){ ?>  
			<option value="<?php echo $row_market['id']; ?>"> <?php echo $row_market['market']; ?> </option>  
		  <?php }?>
	  </select>
	</div>
    <div class="form-group">
      <label for="role">Role</label>
      <select class="form-control" name="role" id="role">
		<option value="" disabled selected>--- Choose Role ---</option>
		  <?php while($row_role = $result_role->fetch_assoc()){ ?>  
			<option value="<?php echo $row_role['id']; ?>"> <?php echo $row_role['role']; ?> </option>  
		  <?php }?>
	  </select>
    </div>
    
    <div class="text-center">
      <button type="submit" class="btn btn-danger" id="psubmit" name="psubmit">Submit</button>
      <a href="assets.php" class="btn btn-secondary">Close</a>
    </div>
    <?php if(isset($msg)) {echo $msg; } ?>
  </form>
</div>
<!-- Only Number for input fields -->
<script>
  function isInputNumber(evt) {
    var ch = String.fromCharCode(evt.which);
    if (!(/[0-9]/.test(ch))) {
      evt.preventDefault();
    }
  }
</script>
<?php
include('includes/footer.php'); 
?>