<?php
define('TITLE', 'Role');
define('PAGE', 'role');

include('../dbConnection.php');
include('includes/header.php'); 

 if(isset($_SESSION['is_user_login'])){
	  $uEmail = $_SESSION['uEmail'];
	  $sql_user_id = "SELECT id, email FROM users WHERE email='".$uEmail."' limit 1";
	  $result_user_id = $conn->query($sql_user_id);
	  $row_user_id = $result_user_id->fetch_assoc();
	  $uID = $row_user_id['id'];
 } else {
  echo "<script> location.href='index.php'; </script>";
 }
?>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.11.3/datatables.min.css"/>
  <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.11.3/datatables.min.js"></script>

<div class="col-sm-9 col-md-10 mt-5">
 <p class="p-2 mb-4 h2">Assigned Role</p>
  <?php 
 $sql = "SELECT roles.role as role,roles.created_at,markets.market as market FROM grants, roles, markets where grants.user_id = {$uID} and grants.status = 1 and grants.role_id = roles.id and roles.market_id = markets.id ";
 
 $result = $conn->query($sql);
 if($result->num_rows > 0){
  echo '<table class="table table-hovered table-striped" id="productTable">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Role</th>
      <th scope="col">Market</th>
      <th scope="col">Assigned Date</th>
    </tr>
  </thead>
  <tbody>';
  while($row = $result->fetch_assoc()){
    echo '<tr>
    <th scope="row">1</th>
    <td>'.$row["role"].'</td>
    <td>'.$row["market"].'</td>
    <td>'.$row["created_at"].'</td>
    </tr>';
   }
   echo '</tbody> </table>';
  } else {
    echo "0 Result";
  }
  ?>
</div>
</div>
<a class="btn btn-danger box" href="role-request.php"><i class="fas fa-plus fa-2x"></i></a>
</div>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
<script type="text/javascript">
 $(document).ready(function(){
	$('#productTable').DataTable();
 });
 
</script>
<?php
include('includes/footer.php'); 
?>