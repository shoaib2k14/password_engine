<?php
$table_name = "role_requests";
$alert = "";

include('../dbConnection.php');
include('controller/select.php');
include('controller/delete.php');
include('controller/status.php');

?>

<!DOCTYPE html>
<html lang="en">

<?php include("includes/head_link.php"); ?>

<body>
	<!-- Main Wrapper -->
	<div class="main-wrapper">
	
	   <?php include("includes/header.php"); ?>
	   
		<?php include("includes/sidebar.php"); ?>
		
		<!-- Page Wrapper -->
		<div class="page-wrapper">
			<div class="content container-fluid">
				<div class="page-header">
				    <div class="row align-items-center">
						<div class="col-12">
							<div class="mt-5">
								<h4 class="card-title float-left mt-2">Roles Requested</h4>
								<!--<a href="add_role.php" class="btn btn-primary float-right veiwbutton ">Add Role</a>-->
							</div>
						</div>
					</div>
					
					<div class="row">
					  <div class="col-12">
					    <?php echo $alert; ?>
					  </div>
					</div>
					
					<div class="row">
					   <div class="col-sm-12">
                          <div class="card card-table">
							 <div class="card-header">
									<h4 class="card-title"></h4>
								</div>
							<div class="card-body booking_card">
								<div class="table-responsive">
									<table class="datatable table table-stripped table table-hover table-center mb-0">
										<thead>
											<tr>
											    <th>User Name</th>
												<th>Role</th>
												<th>Market</th>
												<th>Created_At</th>
												<th>Actions</th>
											</tr>
										</thead>
										<tbody>
											<?php
												if(1){
													//while($row = oci_fetch($result)){
													while($row = mysqli_fetch_assoc($result)){ ?>
														
														 <tr>
														    <td><?=$row["f_name"].' '.$row["l_name"]?></td>
															
															<td><?=$row["role"]?></td>
															
															<td><?=$row["market"]?></td>
															
															<td><?=$row["created_at"]?></td>
															
															
															
															<td>
															    <form action="" method="POST">
																    <input type="hidden" name="primary_key_update" value="<?=$row["id"]?>">
																	
																	<select id="status" name="status" class="form-control">  
																		<option value="<?=$row['is_pending']; ?>"<?php if($row['is_pending']==1){ echo "disabled selected"; } ?>>Pending</option>
																		
																		<option value="<?=$row['is_approved']; ?>"<?php if($row['is_approved']==1){ echo "disabled selected"; } ?>>Approved</option> 
																		
																		<option value="<?=$row['is_declined']; ?>"<?php if($row['is_declined']==1){ echo "disabled selected"; } ?>>Declined</option> 
																	</select>  
																</form>
															</td>
														</tr>
                                               <?php
												  }
                                                }
                                                else{
                                                 echo "No record found";
                                                }
                                              ?>
                                        </tbody>
									</table>
								</div>
							</div>
						</div>
                    </div>
				</div>
			</div>
			
		   <?php include("modal/delete.php"); ?>
			
		</div>
		<!-- /Page Wrapper -->
	</div>
	<!-- /Main Wrapper -->
	
	<!-- jQuery -->
	<script>
		var element = document.getElementById("pwRoleRequested");
		   element.classList.add("active");
		   
		function myFunction(id) {
		   document.getElementById("primary_key_delete").setAttribute('value',id);
		}
    </script>
	
	<?php include("includes/script_link.php"); ?>
	
</body>

</html>