<div id="delete_asset" class="modal fade delete-modal" role="dialog">
	<div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">
			<div class="modal-body text-center">
				<img src="assets/img/sent.png" alt="" width="50" height="46">
				<h3 class="delete_class">Are you sure want to delete this Asset?</h3>
				<div class="m-t-20"> 
					<a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
					<form action="" method="POST">
						<input type="hidden" name="primary_key_delete" id="primary_key_delete">
						<button type="submit" name="delete" class="btn btn-danger">Delete</button>
					</form>
					
				</div>
			</div>
		</div>
	</div>
</div>