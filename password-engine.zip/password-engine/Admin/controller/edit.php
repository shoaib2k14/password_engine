<?php

//start view code
	$id = $_REQUEST['id'];
	$sql = 'select * from '.$table_name.' where id = '.$id;
	$result = oci_parse($connection, $sql);
	oci_execute($result);
	$row = oci_fetch_assoc($result);
// end view code

?>