<?php

if(isset($_REQUEST['delete'])){
	
		$primary_key_delete = $_REQUEST['primary_key_delete'];
		
		$sql = 'DELETE FROM '.$table_name.' WHERE ID=:primary_key_delete';
		
		$parse = oci_parse($conn, $sql);
		
		
		oci_bind_by_name($parse, ':primary_key_delete', $primary_key_delete);
		
		
		$execute = oci_execute($parse);
		
		
		if($execute){
			$alert = '<div class="alert alert-success col-sm-12" role="alert"> Deleted successfully </div>';
		}
		else{
			$alert = '<div class="alert alert-danger col-sm-12" role="alert"> Somthing went wrong </div>';
		}
		
		oci_free_statement($parse);
		oci_close($connection);
}

?>