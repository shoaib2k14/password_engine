<?php

include('../../dbConnection.php');

switch($_REQUEST['key']) {
  case "dR":
    $sql_update = "UPDATE roles SET status = !{$_REQUEST['status']} WHERE id = {$_REQUEST['id']}";
	$conn->query($sql_update);
    break;
  case "dU":
    $sql_update = "UPDATE users SET status = !{$_REQUEST['status']} WHERE id = {$_REQUEST['id']}";
	$conn->query($sql_update);
    break;
  case "dA":
    $sql_update = "UPDATE admins SET status = !{$_REQUEST['status']} WHERE id = {$_REQUEST['id']}";
	$conn->query($sql_update);
    break;
  case "dM":
    $sql_update = "UPDATE markets SET status = !{$_REQUEST['status']} WHERE id = {$_REQUEST['id']}";
	$conn->query($sql_update);
    break;
  case "dO":
    $sql_update = "UPDATE server_owners SET status = !{$_REQUEST['status']} WHERE id = {$_REQUEST['id']}";
	$conn->query($sql_update);
    break;
  case "dS":
    $sql_update = "UPDATE servers SET status = !{$_REQUEST['status']} WHERE id = {$_REQUEST['id']}";
	$conn->query($sql_update);
    break;
  default:
    echo "";
}





/*

if(isset($_REQUEST['update_status'])){
	
		$primary_key_update = $_REQUEST['primary_key_update'];
		
		$sql = 'select id,status from '.$table_name.' WHERE id = '.$primary_key_update;
		
		$result = oci_parse($conn, $sql);
		oci_execute($result);
		$row = oci_fetch($result);

		$status = $row['status'];
		
		$sql = 'UPDATE '.$table_name.' SET STATUS=:status WHERE ID=:primary_key_update';
		
		$parse = oci_parse($connection, $sql);
		
		
		oci_bind_by_name($parse, ':primary_key_update', $primary_key_update);
		
		
		$execute = oci_execute($parse);
		
		
		if($execute){
			$alert = '<div class="alert alert-success col-sm-12" role="alert"> Deleted successfully </div>';
		}
		else{
			$alert = '<div class="alert alert-danger col-sm-12" role="alert"> Somthing went wrong </div>';
		}
		
		oci_free_statement($parse);
		oci_close($connection);
}
*/

?>