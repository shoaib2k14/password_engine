<?php

//$sql = "select * from ".$table_name;

	if($table_name == 'users'){
		//$sql = "select * from users,user_profiles,markets,departments,positions WHERE users.id = user_profiles.user_id AND user_profiles.market_id = markets.id AND user_profiles.department_id = departments.id AND user_profiles.position_id = positions.id";
		
		$sql = "select *,users.id as uId,users.status as uStatus from users,markets WHERE users.market_id = markets.id ORDER BY users.id Desc";
	}
	
	if($table_name == 'admins'){
		$sql = "select * from admins";
	}

	if($table_name == 'roles'){
		$sql = "select * from roles";
	}
    
	if($table_name == 'departments'){
		$sql = "select * from departments";
	}
	
	if($table_name == 'positions'){
		$sql = "select * from positions";
	}
	
	if($table_name == 'markets'){
		$sql = "select * from markets";
	}
	
	if($table_name == 'servers'){
		$sql = "select * from servers";
	}
	
	if($table_name == 'server_owners'){
		$sql = "select * from server_owners";
	}
	
	if($table_name == 'connects'){
		$sql = "select * from connects";
	}
	
	if($table_name == 'role_requests'){
		$sql = "select * from role_requests,users,roles,markets WHERE role_requests.user_id = users.id AND role_requests.role_id = roles.id AND role_requests.market_id = markets.id";
	}


/*** For oracle ***/
	//$result = oci_parse($connection, $sql);
	//oci_execute($result);

/*** For mysql ***/
	$result = mysqli_query($conn,$sql);
	//$count = mysqli_num_rows($result);
	
	
 

?>