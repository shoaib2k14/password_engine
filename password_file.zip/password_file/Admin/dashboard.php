<?php

include('../dbConnection.php');

if(!isset($_SESSION['is_admin_login'])){
	echo "<script> location.href='index.php'; </script>";
 }


if($_SESSION['aRole'] == 0){
	$admin = "Super Admin!";
}else{
	$admin = "Admin!";
}

 // I'm India so my timezone is Asia/Calcutta
     date_default_timezone_set('Asia/Calcutta');

 // 24-hour format of an hour without leading zeros (0 through 23)
     $Hour = date('G');

	if ( $Hour >= 5 && $Hour <= 11 ) {
		$grettings = "Good Morning";
	} else if ( $Hour >= 12 && $Hour <= 17 ) {
		$grettings = "Good Afternoon";
	} else if ( $Hour >= 15 || $Hour <= 4 ) {
		$grettings = "Good Evening";
	}
	
?>

<!DOCTYPE html>
<html lang="en">

<?php include("includes/head_link.php"); ?>

<body>

	<!-- Main Wrapper -->
	<div class="main-wrapper">

		<?php include("includes/header.php"); ?>
	   
		 <?php include("includes/sidebar.php"); ?>
		
		
		<!-- Page Wrapper -->
		<div class="page-wrapper">

			<div class="content container-fluid">

				<!-- Page Header -->
				<div class="page-header">
					<div class="row">
						<div class="col-sm-12 mt-5">
							<h3 class="page-title mt-3"><?php echo $grettings.' '.$admin; ?></h3>
							<!--
							<ul class="breadcrumb">
								<li class="breadcrumb-item active">Dashboard</li>
							</ul>
							-->
						</div>
					</div>
				</div>
				<!-- /Page Header -->
				<div class="row">
					<div class="col-xl-3 col-sm-6 col-12">
						<div class="card board1 fill">
							<div class="card-body">
								<div class="dash-widget-header">
									<div>
										<h3 class="card_widget_header">36</h3>
										<h6 class="text-muted">Total Request</h6>
									</div>
									<div class="ml-auto mt-md-3 mt-lg-0">
										<span class="opacity-7 text-muted font-size-2rem"><i class="fa fa-paper-plane-o"></i></span>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-xl-3 col-sm-6 col-12">
						<div class="card board1 fill">
							<div class="card-body">
								<div class="dash-widget-header">
									<div>
										<h3 class="card_widget_header">180</h3>
										<h6 class="text-muted">Connections</h6>
									</div>
									<div class="ml-auto mt-md-3 mt-lg-0">
										<span class="opacity-7 text-muted font-size-2rem"><i class="fa fa-plug"></i></span>
									</div>
								</div>

							</div>
						</div>
					</div>
					<div class="col-xl-3 col-sm-6 col-12">
						<div class="card board1 fill">
							<div class="card-body">
								<div class="dash-widget-header">
									<div>
										<h3 class="card_widget_header">158</h3>
										<h6 class="text-muted">Total Users</h6>
									</div>
									<div class="ml-auto mt-md-3 mt-lg-0">
										<span class="opacity-7 text-muted font-size-2rem"><i class="fa fa-user-o"></i></span>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-xl-3 col-sm-6 col-12">
						<div class="card board1 fill">
							<div class="card-body">
								<div class="dash-widget-header">
									<div>
										<h3 class="card_widget_header">34</h3>
										<h6 class="text-muted">Roles</h6>
									</div>
									<div class="ml-auto mt-md-3 mt-lg-0">
										<span class="opacity-7 text-muted font-size-2rem"><i class="fa fa-users"></i></span>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				
			</div>
		</div>
		<!-- /Page Wrapper -->
	</div>

		
		
	</div>
	<!-- /Main Wrapper -->

	<script>
		var element = document.getElementById("dashboard");
		   element.classList.add("active");
		   element.classList.add("active");
	</script>
	
	<?php include("includes/script_link.php"); ?>

</body>

</html>