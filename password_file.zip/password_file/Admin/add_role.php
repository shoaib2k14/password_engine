<?php
$alert = '';

include("dbConnection.php");
include("controller/insert.php");

?>


<!DOCTYPE html>
<html lang="en">

<?php include("header/head_link.php"); ?>

<body>

	<!-- Main Wrapper -->
	<div class="main-wrapper">
       
	   <?php include("header/header.php"); ?>
	   
		 <?php include("header/sidebar.php"); ?>
		
		<!-- Page Wrapper -->
		<div class="page-wrapper">

			<div class="content container-fluid">

						<!-- /Page Header -->
				<div class="row">
				     <div class="content container-fluid">
				<div class="page-header">
					<div class="row align-items-center">
						<div class="col">
							<h3 class="page-title mt-5">Add Role</h3>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-lg-12">
						<form>
							<div class="row formtype">
								<div class="col-md-4">
									<div class="form-group">
										<label>Name</label>
										<input class="form-control" type="text" name="name">
									</div>
								</div>
								<div class="col-md-4">
									<div class="form-group">
										<label>Description</label>
										<input class="form-control" type="text" name="description">
									</div>
								</div>
								<div class="col-md-4">
								  <div class="form-group">
								    <label>Status</label>
									  <select class="form-control" id="status" name="status">
									    <option value="1">Active</option>
										<option value="0">Inactive</option>
									   </select>
								   </div>
								 </div>
							</div>
						</form>
					</div>
				</div>
				<div class="col-md-12 text-center">
				<button type="button" class="btn btn-primary" name="insert_role">Create Role</button>
				</div>
			</div>
		</div>		
				</div>
				
			</div>
		</div>
		<!-- /Page Wrapper -->
	</div>

		
		
	</div>
	<!-- /Main Wrapper -->

	<!-- jQuery -->
	<script>
		var element = document.getElementById("pwroles");
		   element.classList.add("active");
		   element.classList.add("active");
	</script>
	
	<?php include("header/script_link.php"); ?>
	
</body>

</html>