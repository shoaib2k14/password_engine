<?php
$alert = '';

include("dbConnection.php");
include("controller/insert.php");

?>


<!DOCTYPE html>
<html lang="en">

<?php include("header/head_link.php"); ?>

<body>

	<!-- Main Wrapper -->
	<div class="main-wrapper">

		<?php include("header/header.php"); ?>
	   
		 <?php include("header/sidebar.php"); ?>
		
		<!-- Page Wrapper -->
		<div class="page-wrapper">

			<div class="content container-fluid">

					<!-- /Page Header -->
				<div class="row">
				     <div class="content container-fluid">
				<div class="page-header">
					<div class="row align-items-center">
						<div class="col">
							<h3 class="page-title mt-5">Add User</h3>
						</div>
					</div>
				</div>
				
				<div class="row">
				  <?php echo $alert; ?>
				</div>

				<div class="row">
					<div class="col-lg-12">
						<form action="" method="POST">
							<div class="row formtype">
								<div class="col-md-4">
									<div class="form-group">
										<label>First Name</label>
										<input class="form-control" type="text" name="f_name">
									</div>
								</div>
								<div class="col-md-4">
									<div class="form-group">
										<label>Last Name</label>
										<input class="form-control" type="text" name="l_name">
									</div>
								</div>
								<div class="col-md-4">
									<div class="form-group">
										<label>Email</label>
										<input class="form-control" type="email" name="email">
									</div>
								</div>
								<div class="col-md-4">
									<div class="form-group">
										<label>Phone Number</label>
										<input class="form-control" type="number" name="phone">
									</div>
								</div><div class="col-md-4">
									<div class="form-group">
										<label>Mobile Number</label>
										<input class="form-control" type="number" name="mobile">
									</div>
								</div>
								<div class="col-md-4">
									<div class="form-group">
										<label>Company</label>
										<input class="form-control" type="text" name="company">
									</div>
								</div>
								<div class="col-md-4">
									<div class="form-group">
										<label>Department</label>
										<input class="form-control" type="text" name="department">
									</div>
								</div>
								<div class="col-md-4">
									<div class="form-group">
										<label>Position</label>
										<input class="form-control" type="text" name="position">
									</div>
								</div>								
								<div class="col-md-4">
								  <div class="form-group">
								    <label>Status</label>
									  <select class="form-control" id="status" name="status">
										  <option value="1">Active</option>
										  <option value="0">Inactive</option>
									  </select>
								  </div>
								</div>
							</div>
					    </div>
					    <div class="col-md-12 text-center">
					       <button type="submit" class="btn btn-primary" name="insert_user">Create User</button>
					    </div>
				     </form>
                   </div>
			    </div>
		      </div>		
		    </div>
		  </div>
		</div>
		<!-- /Page Wrapper -->
	  </div>
    </div>
	<!-- /Main Wrapper -->

	<!-- jQuery -->
	<script>
		var element = document.getElementById("pwusers");
		   element.classList.add("active");
	</script>
	
	<?php include("header/script_link.php"); ?>

</body>

</html>