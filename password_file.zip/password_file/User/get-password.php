<?php
define('TITLE', 'Get-Password');
define('PAGE', 'getPassword');


include('../dbConnection.php');
include('includes/header.php'); 


 if(isset($_SESSION['is_user_login'])){
     $uEmail = $_SESSION['uEmail'];
   
     $sql_user = "SELECT * FROM users where email = '{$uEmail}'";
	 $result_user = $conn->query($sql_user);
	 $row_user = $result_user->fetch_assoc();
	 $user_id = $row_user['id'];
 } 
 else {
   echo "<script> location.href='index.php'; </script>";
 }
?>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.11.3/datatables.min.css"/>
  <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.11.3/datatables.min.js"></script>

<div class="col-10 mt-5">
 <p class="p-2 mb-4 h2">Passwords</p>
  <?php 
 $pSql = "SELECT * FROM files WHERE files.user_id = $user_id AND status = 1 ORDER BY created_at desc";
 
 $pResult = $conn->query($pSql);
 if($pResult->num_rows > 0){ ?>
 
 <table class="table table-hovered table-striped" id="productTable">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">File Name</th>
      <th scope="col">Password</th>
	  <th scope="col">Expire At</th>
      <th scope="col">Assigned Date</th>
    </tr>
  </thead>
  <tbody>
  <?php $count = 0; 
        while($pRow = $pResult->fetch_assoc()){; ?>
   <tr>
    <th scope="row"><?php echo ++$count; ?></th>
    <td><?php echo $pRow["file"]; ?></td>
    <td><?php echo $pRow["password"]; ?></td>
	<td><?php echo $pRow["expire_at"]; ?></td>
    <td><?php echo $pRow["created_at"]; ?></td>
   </tr>
   <?php } ?>
  </tbody> 
 </table>
  <?php } else { echo "0 Result"; } ?>
  
  <a class="btn btn-danger box" onclick="openModal()" style="color:white;">New Request <i class="fas fa-plus fa-1x"></i></a>
</div>
  
 
 





<div class="modal fade delete-modal" id="requestModal">
  <div class="modal-dialog modal-dialog-centered modal-lg">
	<div class="modal-content">

	  <!-- Modal Header -->
	  <div class="modal-header">
		<h4 class="modal-title">Password Request</h4>
		<button type="button" class="close" data-dismiss="modal">&times;</button>
	  </div>

	  <!-- Modal body -->
	  <div class="modal-body">
	  
	   <div class="card mx-2">
		 <div class="card-header">Employee ID : <?php echo $row_user['employee_id']; ?></div>
		   <div class="card-body">
				<form id="addFormData">
				  <div class="form-group">
					 <input type="hidden" class="form-control" type="text" name="employee_id" value="<?php echo $row_user['employee_id']; ?>">
					 
					 <label for="server">Select Market</label>
					 <select class="form-control" name="market" id="market" onchange="getRole(this.value)"> 
						  <option value="" disabled selected>Select Market</option> 
							<?php 
							  $mSql = "SELECT * FROM markets WHERE status = 1";   
							  $mResult = $conn->query($mSql);			    
							  while($mRow = mysqli_fetch_array($mResult)) { ?> 
								  <option value="<?php echo $mRow['id']; ?>"><?php echo $mRow['market']; ?></option>
						   <?php } ?>				 
					 </select>
					 
					 <div class="mt-3" id="GetRole"></div>
					 
					 <div class="mt-3" id="GetServer"></div>
					 
				  </div>
				 </div>
				 </div> 
				 
				  <div class="modal-footer float-right">
				   <button type="button" class="btn btn-primary" id="sendReqButton" onclick="sendFile(this.value)">Request</button>
				   <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
				 </div>
				</form>
			 
		  
	   </div>
	  <!-- Modal body end-->
	</div>
  </div>
</div>


<div id="getStatusModal"></div>



<?php 
  include('includes/footer.php'); 
  $conn->close();
?>

<script>
$("#sendReqButton").hide();

function openModal() {
	 $('#requestModal').modal('show');
	 $('#myModal').modal('hide');
	
 }
 


 function getRole(market) {
	 //alert(market);
	 $.ajax({
		 url:'modal/getRoleModal.php',
		 type:'POST',
		 data:{
			   market:market,
			 },
		 success:function(result){
			 $('#GetRole').html(result);
		 }
	 });
 }
 
 
 function getServer(role) {
	 //alert(role);
	 $.ajax({
		 url:'modal/getServerModal.php',
		 type:'POST',
		 data:{
			   role:role,
			 },
		 success:function(result){
			 $('#GetServer').html(result);
		 }
	 });
 }
 
 function getReqButton(server) {
	 //alert(server);
	 $("#sendReqButton").show();
 }
 
 
 function sendFile() {
	 //alert('hello');
	 $.ajax({
		 url:'controller/sendMail.php',
		 type:'POST',
		 data:$('#addFormData').serialize(),
		 success:function(result){
			 $('#getStatusModal').html(result);
			 $('#requestModal').modal('hide');
			 $("#sendReqButton").hide();
			 $("#GetRole").hide();
			 $("#GetServer").hide();
			 $('#successMsgModal').modal('show');
		}
	 });
   }
   
   
 function reload(){
	 $('#requestModal').modal('hide');
	 $("#sendReqButton").hide();
	 $("#GetRole").hide();
	 $("#GetServer").hide();
	 $('#successMsgModal').modal('hide');
	 location.reload();
  }
  
 $(document).ready(function(){
	$('#productTable').DataTable();
 });
</script>