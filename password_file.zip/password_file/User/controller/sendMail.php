<?php

include('../../dbConnection.php');

$market = $_REQUEST['market'];
$role = $_REQUEST['role'];
$server = $_REQUEST['server'];
$employee_id = $_REQUEST['employee_id'];

$msg = 0;
$passcode = rand(100000, 999999);

 $sql = "SELECT * from servers Where id = $server AND market_id = $market";
 $result = mysqli_query($conn , $sql);
 $row = mysqli_fetch_assoc($result);
 $host_name = $row['host_name'];
 $ip_address = $row['ip_address'];
 $password = $row['password'];
 
 
 if(mysqli_num_rows($result)==1){
	 
	$myfile = fopen($employee_id.".txt", "w") or die("Unable to open file!");
	$txt = "Host Name: ".$host_name.", Ip Address: ".$ip_address.", Password: ".$password;
	fwrite($myfile, $txt);
	fclose($myfile);
	
	
	
	//$rootDir = realpath($_SERVER["DOCUMENT_ROOT"]);
	//echo __FILE__;
	$input= dirname(__FILE__).'/'.$employee_id.'.txt';
	//$input= dirname(__FILE__).'/shoaib.pdf';
	
	$zip_name = date('His-Ymd-').$employee_id.'.zip';
	$zip = new ZipArchive;
	$res = $zip->open($zip_name, ZipArchive::CREATE);
	//$res = $zip->setPassword($passcode);
	
	if($res === TRUE){
		$zip->addFile($input);
		$zip->close();
		unlink($employee_id.'.txt');
		$msg = 1;
		
		$sql_u = "SELECT id FROM users WHERE employee_id= '$employee_id'";
	    $result_u = $conn->query($sql_u);
	    $row_u = $result_u->fetch_assoc();
	    $uID = $row_u['id'];
		
		$sql_i = "INSERT INTO files (user_id, file, password) VALUES('$uID', '$zip_name', '$passcode')";
		$conn->query($sql_i);
	}
	else{
		$msg = 0;
	}
	

 }

?>


<?php
if($msg == 1){?>
	<div id="successMsgModal" class="modal fade delete-modal" role="dialog">
		<div class="modal-dialog modal-dialog-centered">
			<div class="modal-content">
			   <div class="modal-body text-center">
					<button type="button" class="close" onclick="reload()">&times;</button>
					<h5 class="delete_class">Zip file has sent on your mail</h5>
					<p>Thanks</p>
				</div>
			</div>
		</div>
	</div>
<?php } ?>



<?php
if($msg == 0){?>
	<div id="successMsgModal" class="modal fade delete-modal" role="dialog">
		<div class="modal-dialog modal-dialog-centered">
			<div class="modal-content">
			   <div class="modal-body text-center">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h5 class="delete_class">Please try after some time</h5>
					<p>Thanks</p>
				</div>
			</div>
		</div>
	</div>
<?php } ?>