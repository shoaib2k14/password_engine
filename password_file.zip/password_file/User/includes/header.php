<!DOCTYPE html>
<html lang="en">

<head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <meta http-equiv="X-UA-Compatible" content="ie=edge">
 <title><?php echo TITLE ?></title>
 <link rel="shortcut icon" type="image/x-icon" href="../img/logo.png">
 <!-- Bootstrap CSS -->
 <link rel="stylesheet" href="assets/css/bootstrap.min.css">

 <!-- Font Awesome CSS -->
 <link rel="stylesheet" href="assets/css/all.min.css">

 <!-- Custome CSS -->
 <link rel="stylesheet" href="assets/css/custom.css">
 
 <!-- DataTable -->
 <link rel="stylesheet" type="text/css" href="assets/css/datatables.min.css"/>

   <style>
   #logo{
	   width: 35px;
   }
   .sidebar{
	   height:92vh;
   }
   </style>
</head>

<body>
 <!-- Top Navbar -->
 <nav class="navbar navbar-dark fixed-top bg-danger p-0 shadow">
  <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="dashboard.php">
    <img id="logo" src="assets/img/vodafone-logo.png"/> Vodafone
  </a>
 </nav>

 <!-- Side Bar -->
 <div class="container-fluid mt-5">
  <div class="row">
   <nav class="col-sm-3 col-md-2 bg-light sidebar py-5 d-print-none">
    <div class="sidebar-sticky">
     <ul class="nav flex-column">
      <li class="nav-item">
       <a class="nav-link <?php if(PAGE == 'dashboard') { echo 'active'; } ?> " href="dashboard.php">
        <i class="fas fa-tachometer-alt"></i>
        Dashboard
       </a>
      </li>
      <li class="nav-item">
       <a class="nav-link <?php if(PAGE == 'profile') { echo 'active'; } ?>" href="profile.php">
        <i class="fab fa-accessible-icon"></i>
        Profile
       </a>
      </li>
      <li class="nav-item">
       <a class="nav-link <?php if(PAGE == 'role') { echo 'active'; } ?>" href="role-assigned.php">
        <i class="fas fa-align-center"></i>
        Assigned Role
       </a>
      </li>
	  <li class="nav-item">
       <a class="nav-link <?php if(PAGE == 'getPassword') { echo 'active'; } ?>" href="get-password.php">
        <i class="fas fa-database"></i>
        Get Password
       </a>
      </li>
      <li class="nav-item">
       <a class="nav-link <?php if(PAGE == 'requested') { echo 'active'; } ?>" href="role-requested.php">
        <i class="fas fa-database"></i>
        Requested Role
       </a>
      </li>
      <li class="nav-item">
       <a class="nav-link <?php if(PAGE == 'changepass') { echo 'active'; } ?>" href="changepass.php">
        <i class="fas fa-key"></i>
        Change Password
       </a>
      </li>
      <li class="nav-item">
       <a class="nav-link" href="../logout.php">
        <i class="fas fa-sign-out-alt"></i>
        Logout
       </a>
      </li>
     </ul>
    </div>
   </nav>