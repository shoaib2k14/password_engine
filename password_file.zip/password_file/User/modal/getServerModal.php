<?php
include('../../dbConnection.php');

$role=$_POST['role'];
//$market=$_POST['market'];
?>

 <label for="server">Select Server</label>
 <select class="item inn form-control" name="server" onchange="getReqButton(this.value)"> 
	  <option value="" disabled selected>Select Server</option> 
		<?php 
		  $sql = "SELECT * FROM servers WHERE status = 1";   
		  $result = $conn->query($sql);			    
		  while($row = mysqli_fetch_array($result)) { ?> 
			  <option value="<?php echo $row['id']; ?>"><?php echo $row['host_name']; ?></option>
	   <?php } ?>				 
 </select>