<?php
include('../../dbConnection.php');

$uEmail = $_SESSION['uEmail'];

$msg = 0;

  
  if(($_REQUEST['role'] == "") || ($_REQUEST['market'] == "")){
    $msg = 0;
  }else {
	  
     $role_id = $_REQUEST['role'];
     $market_id = $_REQUEST['market'];
	 $user_id=$_POST['id'];
 
     $sql = "INSERT INTO role_requests (user_id, role_id, market_id) VALUES ($user_id,$role_id,$market_id)";
   
   if($conn->query($sql) == TRUE){
      $msg = 2;
	  echo "Error: " . $sql . "<br>" . $conn->error;
   }else {
    
    $msg = 0;
   }
 }

  
?>


<?php
if($msg == 2){?>
	<div id="successMsgModal" class="modal fade delete-modal" role="dialog">
		<div class="modal-dialog modal-dialog-centered">
			<div class="modal-content">
			   <div class="modal-body text-center">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h5 class="delete_class">Request has been sent</h5>
					<p>Thanks</p>
				</div>
			</div>
		</div>
	</div>
<?php } ?>



<?php
if($msg == 0){?>
	<div id="successMsgModal" class="modal fade delete-modal" role="dialog">
		<div class="modal-dialog modal-dialog-centered">
			<div class="modal-content">
			   <div class="modal-body text-center">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h5 class="delete_class">Please try after some time</h5>
					<p>Thanks</p>
				</div>
			</div>
		</div>
	</div>
<?php } ?>
