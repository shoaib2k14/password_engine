<div class="col-sm-5 mt-5" id="profile_view">
  <!-- Main Content area Start Last -->
 <h3 class="text-center">Profile Details</h3>

 <table class="table table-bordered">
  <tbody>
   <tr>
    <td>Name</td>
    <td>
     <?php if(isset($row_user['f_name'])) {echo $row_user['f_name'].' '.$row_user['l_name']; }?>
    </td>
   </tr>
   <tr>
    <td>Email</td>
    <td>
     <?php if(isset($row_user['email'])) {echo $row_user['email']; }?>
    </td>
   </tr>
   <tr>
    <td>Mobile</td>
    <td>
     <?php if(isset($row_user['mobile'])) {echo $row_user['phonecode'].$row_user['mobile']; }?>
    </td>
   </tr>
   <tr>
    <td>DOB</td>
    <td>
     <?php if(isset($row_user['dob'])) {echo $row_user['dob']; }?>
    </td>
   </tr>
   <tr>
    <td>DOJ</td>
    <td>
     <?php if(isset($row_user['doj'])) {echo $row_user['doj']; }?>
    </td>
   </tr>
   <tr>
    <td>Employee Id</td>
    <td>
     <?php if(isset($row_user['employee_id'])) {echo $row_user['employee_id']; }?>
    </td>
   </tr>
   
   
   <tr>
    <td>Department</td>
    <td>
     <?php if(isset($row['department_id'])) {echo $row['department_id']; }?>
    </td>
   </tr>
   <tr>
    <td>Market</td>
    <td>
     <?php if(isset($row['market_id'])) {echo $row['market_id']; }?>
    </td>
   </tr>
   <tr>
    <td>Line Manager</td>
    <td>
     <?php if(isset($row['line_manager_id'])) {echo $row['line_manager_id']; }?>
    </td>
   </tr>
   <tr>
    <td>Office Address</td>
    <td>
     <?php if(isset($row['office_address'])) {echo $row['office_address']; }?>
    </td>
   </tr>
   <tr>
    <td>Country</td>
    <td>
     <?php if(isset($row['country_id'])) {echo $row['country_id']; }?>
    </td>
   </tr>
   <tr>
    <td>State</td>
    <td>
     <?php if(isset($row['state_id'])) {echo $row['state_id']; }?>
    </td>
   </tr>
   <tr>
    <td>City</td>
    <td>
     <?php if(isset($row['city_id'])) {echo $row['city_id']; }?>
    </td>
   </tr>
   <tr>
    <td>Pin Code</td>
    <td>
     <?php if(isset($row['pin_code'])) {echo $row['pin_code']; }?>
    </td>
   </tr>
   <tr>
    <td>Address</td>
    <td>
     <?php if(isset($row['address'])) {echo $row['address']; }?>
    </td>
   </tr>
   <tr>
    <td>Fathers Name</td>
    <td>
     <?php if(isset($row['fathers_name'])) {echo $row['fathers_name']; }?>
    </td>
   </tr>
   <tr>
    <td>Mothers Name</td>
    <td>
     <?php if(isset($row['Mothers_name'])) {echo $row['Mothers_name']; }?>
    </td>
   </tr>
   
   </tbody>
 </table>
 <div class="text-center">
   <button class="btn btn-danger" onclick="edits()">Edit</button>
   <button class="btn btn-secondary" onclick="hide()">Close</button>
 </div>
 
</div>


<div class="col-sm-5 mt-5 jumbotron" id="profile_edit">
  <?php include('profile_edit.php'); ?>
</div>




  <!-- below msg display if required fill missing or form submitted success or failed -->
  <?php if(isset($msg)) {echo $msg; } ?>
</div> <!-- Main Content area End Last -->
</div> <!-- End Row -->
</div> <!-- End Container -->
<!-- Only Number for input fields -->
<script>
  function isInputNumber(evt) {
    var ch = String.fromCharCode(evt.which);
    if (!(/[0-9]/.test(ch))) {
      evt.preventDefault();
    }
  }
</script>